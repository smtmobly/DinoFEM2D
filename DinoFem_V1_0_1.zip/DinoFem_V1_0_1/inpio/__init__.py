from inpio._abaqus import read, write
