import sys

import numpy
import numpy as np


concatenate = numpy.concatenate
array = np.array


def dot(a,b):
    return np.dot(a, b)


def copy(a):
    b=numpy.copy(a)
    return b


def Matrix(n,m):
    return np.zeros((n, m), dtype=float)


def solve(a, b):
    v = np.dot(np.linalg.inv(a),b)
    return v


def gauss_2d_triangle(kernel_fun, vertices):
    # -----
    # t -->x_hat
    # s--> y_hat
    # t ---> (1+ksi)/2
    # s----> (1-ksi)*(1+eta)/4
    x1 = vertices[0][0]
    y1 = vertices[0][1]
    x2 = vertices[1][0]
    y2 = vertices[1][1]
    x3 = vertices[2][0]
    y3 = vertices[2][1]

    def x(t, s):
        return (x2-x1)*t + (x3-x1)*s + x1

    def y(t, s):
        return (y2-y1)*t + (y3-y1)*s + y1

    jacobi = (x2-x1)*(y3-y1)-(x3-x1)*(y2-y1)

    nodes = [0.9061798459, -0.9061798459, 0.5384693101, -0.5384693101, 0]
    weights = [0.2369268851,0.2369268851,0.4786286705,0.4786286705,0.5688888889]
    gpn = 5

    int_value = 0
    for i in range(gpn):
        ksi = nodes[i]
        for j in range(gpn):
            eta = nodes[j]
            x_hat = (1+ksi)/2
            y_hat = (1 - ksi) * (1 + eta) / 4
            gauss_jacobi = (1-ksi)/8

            item = weights[i]*weights[j]*kernel_fun(x(x_hat, y_hat), y(x_hat, y_hat))*gauss_jacobi*jacobi
            int_value += item
    return int_value


def gauss_1d(kernel_fun, domain):
    """
    :param kernel_fun:  输入的被积函数
    :param domain:           积分区域domain = (a,b)
    :return:            积分结果
    """
    gpn = 5
    a = domain[0]
    b = domain[1]

    def transform(t):
        return (b-a)/2*t+(b+a)/2
    nodes = [0.9061798459, -0.9061798459, 0.5384693101, -0.5384693101, 0]
    weights = [0.2369268851,0.2369268851,0.4786286705,0.4786286705,0.5688888889]
    jacob = (b-a)/2
    int_value = 0
    for k in range(gpn):
        int_value += jacob*weights[k]*kernel_fun(transform(nodes[k]))
    return int_value


if __name__ == '__main__':
    from math import exp
    def f(x,y):
        return 1
    vertices = [(1,4),(3,4),(2,5)]
    print(gauss_2d_triangle(f,vertices))
    print(gauss_2d_triangle(f,vertices)-1)