# ----------------------------------------------
# inp 文件说明
# Heading 头信息
# NODE 节点信息
#  ******* E L E M E N T S ************* 注释信息
# ELEMENT 单元信息
# *ELEMENT, type=T3D2, ELSET=Line2
# *ELEMENT, type=CPS3, ELSET=Surface1
# ELSET 单元集合
# NSET 节点集合
# 根据边界名称，来修改边界类型
# 使用的时候，有一个名称，类型对
#
# ------------------------------------------------
from inpio import read
import numpy as np
from DinoFem.exceptions import ReadError


def InpAnalytic(inp_file,pattern='linear'):

    """
    :param inp_file: inp文件
    :param pattern:  单元类型，line 线性单元，quad，二次单元
    """
    if pattern == 'linear':
        return InpAnalyticLinear(inp_file)
    elif pattern == 'quad':
        return InpAnalyticQuad(inp_file)
    else:
        raise ReadError(f'{pattern}  is not supported, linear or quad')


class InpAnalyticQuad:
    def __init__(self,inp_file):
        self.__boundaries_names = []  # 边界名称，及对应的列表的index
        self.__content = None
        self.__P = None
        self.__T = None
        self.__BN = None  # 边界编号，所属于的cell编号，线的点编号1，线的点编号2
        self.__analytic(inp_file)

    @property
    def boundaries_name(self):
        return self.__boundaries_names

    @property
    def T(self):
        return self.__T

    @property
    def P(self):
        return self.__P

    @property
    def BN(self):
        return self.__BN

    def __analytic(self,inp_file):
        mesh = read(inp_file)
        boundary_names = list(mesh.point_sets.keys())
        n = 0
        for i in range(len(boundary_names)):
            n += len(mesh.point_sets[boundary_names[i]])
        bbb = []
        for i in range(len(boundary_names)):
            b = mesh.point_sets[boundary_names[i]]
            a = i * np.ones((len(b),),dtype=int)
            bbb.append(np.array(list(zip(a, b))))
        BN = None
        if len(bbb) > 1:
            a = bbb[0]
            for i in range(len(bbb) - 1):
                a = np.concatenate((a, bbb[i + 1]))

            BN = a
        elif len(bbb) == 1:
            BN = bbb[0]
        else:
            pass
        self.__P = mesh.points
        self.__T = mesh.cells_dict['triangle6']
        self.__BN = BN
        self.__boundaries_names = boundary_names


class InpAnalyticLinear:
    def __init__(self,inp_file):
        self.__boundaries_names = []  # 边界名称，及对应的列表的index
        self.__content = None
        self.__P = None
        self.__T = None
        self.__BN = None  # 边界编号，所属于的cell编号，线的点编号1，线的点编号2
        self.__analytic(inp_file)

    @property
    def boundaries_name(self):
        return self.__boundaries_names

    @property
    def T(self):
        return self.__T

    @property
    def P(self):
        return self.__P

    @property
    def BN(self):
        return self.__BN

    def __analytic(self,inp_file):
        mesh = read(inp_file)
        boundary_names = list(mesh.point_sets.keys())
        n = 0
        for i in range(len(boundary_names)):
            n += len(mesh.point_sets[boundary_names[i]])
        bbb = []
        for i in range(len(boundary_names)):
            b = mesh.point_sets[boundary_names[i]]
            a = i * np.ones((len(b),),dtype=int)
            bbb.append(np.array(list(zip(a, b))))
        BN = None
        if len(bbb) > 1:
            a = bbb[0]
            for i in range(len(bbb) - 1):
                a = np.concatenate((a, bbb[i + 1]))

            BN = a
        elif len(bbb) == 1:
            BN = bbb[0]
        else:
            pass
        self.__P = mesh.points
        self.__T = mesh.cells_dict['triangle']
        self.__BN = BN
        self.__boundaries_names = boundary_names


class InpAnalyticLinear1:
    def __init__(self,inp_file):
        self.__nodes_info = None
        self.__lines_info = []
        self.__surfaces_info = None
        self.__boundaries_info = []
        self.__boundaries_names = []  # 边界名称，及对应的列表的index
        self.__content = None
        self.__P = []
        self.__T = []
        self.__BN = []  # 边界编号，所属于的cell编号，线的点编号1，线的点编号2
        self.__Lines = []
        self.__read_and_del_comment(inp_file) # d读取文件并删除注释
        self.__analytic()

    @property
    def boundaries_name(self):
        return self.__boundaries_names

    @property
    def T(self):
        return self.__T

    @property
    def P(self):
        return self.__P

    @property
    def BN(self):
        return self.__BN

    def __analytic(self):
        self.__split_info()
        self.__get_nodes()
        self.__get_lines()
        self.__get_surfaces()
        self.__get_boundaries()

    def __read_and_del_comment(self,inp_file):
        with open(inp_file, 'r') as f:
            content = f.readlines()
            # 去掉注释
            comment_index = []

            for n in range(len(content)):
                current = content[n].strip()
                if current[:2] == "**":
                    comment_index.append(n)

            for n in comment_index:
                content.pop(n)
            self.__content = content

    def __split_info(self):
        key_index = []
        for n in range(len(self.__content)):
            current = self.__content[n].strip()
            if "Heading" in current:
                continue
            if "NODE" in current:
                ki = current, n
                key_index.append(ki)
                continue
            if "ELEMENT" in current:
                ki = current, n
                key_index.append(ki)
                continue
            if "ELSET" in current:
                ki = current, n
                key_index.append(ki)
                continue
            if "NSET" in current:
                ki = current, n
                key_index.append(ki)
                continue

        key_start_end = []
        for i in range(len(key_index) - 1):
            kse = key_index[i][0], key_index[i][1], key_index[i + 1][1]
            key_start_end.append(kse)
        last = key_index[len(key_index) - 1]
        key_start_end.append((last[0], last[1], len(self.__content)))
        for item in key_start_end:
            key = item[0]
            if "NODE" in key:
                self.__nodes_info = item
                continue
            if "ELEMENT" in key and "Line" in key:
                self.__lines_info.append(item)
                continue
            if "ELEMENT" in key and "Surface" in key:
                self.__surfaces_info = item
                continue
            if "ELSET" in key:
                self.__boundaries_info.append(item)

    def __get_nodes(self):
        # NODE
        start = self.__nodes_info[1]
        end = self.__nodes_info[2]
        size = end - start-1
        for i in range(size):
            current = self.__content[start+1+i].strip()
            # print(current)
            dd = current.split(",")

            point = float(dd[1]),float(dd[2]), float(dd[3])
            self.__P.append(point)

    def __line_start_index(self):
        return int(self.__content[self.__lines_info[0][1] + 1].strip().split(',')[0])

    def __get_lines(self):
        # Line
        for info in self.__lines_info:
            start = info[1]
            end = info[2]
            size = end - start - 1
            for i in range(size):
                current = self.__content[start + 1 + i].strip()
                # print(current)
                dd = current.split(",")

                indexes = int(dd[1])-1, int(dd[2])-1
                self.__Lines.append(indexes)

    def __get_surfaces(self):
        # Surface
        start = self.__surfaces_info[1]
        end = self.__surfaces_info[2]
        size = end - start-1
        for i in range(size):
            current = self.__content[start+1+i].strip()
            # print(current)
            dd = current.split(",")

            point = int(dd[1])-1, int(dd[2])-1, int(dd[3])-1
            self.__T.append(point)

    def __get_boundaries(self):
        bn = []
        # print(self.__boundaries_info)
        for i in range(len(self.__boundaries_info)):
            b=self.__boundaries_info[i]
            head = b[0].strip()
            start = b[1]
            end = b[2]
            boundary_name = head.split("=")[1]
            self.__boundaries_names.append(boundary_name)
            size = end - start - 1
            dd = ""
            for i in range(size):
                current = self.__content[start + 1 + i].strip()
                dd += current
            dd1 = []  # 线的编号
            for s in dd.strip().split(','):
                if s.strip().isdigit():
                    dd1.append(int(s))
            bn.append(dd1)
        for alpha in range(len(self.T)):
            for i in range(len(self.__boundaries_info)):
                boundary_index = i
                for j in bn[boundary_index]:
                    lines_index = j - self.__line_start_index()
                    indexes = self.__Lines[lines_index]
                    if indexes[0] in self.T[alpha] and indexes[1] in self.T[alpha]:
                        b0 = boundary_index,alpha,indexes[0],indexes[1]
                        self.__BN.append(b0)
                    else:
                        pass


if __name__ == '__main__':
    data = InpAnalytic("../examples/t1.inp")
    print(data.boundaries_name)
    print(data.BN)












