from DinoFem.exceptions import ParamTypeError


class BasisLocalFun2DLinear:
    def __init__(self):
        self.basis_type = 201
        self.basis_type_test = 201
        self.number_of_local_basis = 3
        self.number_of_boundary_cell_node = 2

    @classmethod
    def FE_basis_local_fun_2D(cls,x, y,
                              vertices,
                              basis_type,
                              basis_index,
                              basis_der
                              ):
        # vertices  对应单元的节点 [(x1,y1),(x2,y2),(x3,y3)]
        # basis_type 表示基函数类型
        # basis_index  是对应第几个局部基函数
        # basis_der   = [对x求导阶数，对y求导阶数]

        # 201: 2D linear
        # 202 : 2D quadratic

        xn1 = vertices[0][0]
        yn1 = vertices[0][1]
        xn2 = vertices[1][0]
        yn2 = vertices[1][1]
        xn3 = vertices[2][0]
        yn3 = vertices[2][1]
        jacobi = (xn2-xn1)*(yn3-yn1)-(xn3-xn1)*(yn2-yn1)
        der_x = basis_der[0]
        der_y = basis_der[1]
        if basis_type == 201:
            if basis_index == 0:
                if der_x == 0 and der_y == 0:
                    # psi_n1(x,y)
                    psi_n1 = -1*((yn3-yn1)*(x-xn1)-(xn3-xn1)*(y-yn1))/jacobi\
                             - 1 * (-1*(yn2-yn1)*(x-xn1)+(xn2-xn1)*(y-yn1))/jacobi + 1
                    return psi_n1
                elif der_x == 1 and der_y == 0:
                    # partial_x_psi_n1
                    partial_x_psi_n1 = (yn2-yn3)/jacobi
                    return partial_x_psi_n1
                elif der_x == 0 and der_y == 1:
                    # partial_y_psi_n1
                    partial_y_psi_n1 = (xn3-xn2)/jacobi
                    return partial_y_psi_n1
                else:
                    raise ParamTypeError(f'please check your input der {(der_x,der_y)} ')
            if basis_index == 1:
                if der_x == 0 and der_y == 0:
                    # psi_n1(x,y)
                    psi_n2 = ((yn3 - yn1)*(x - xn1) - (xn3 - xn1) * (y - yn1)) / jacobi
                    return psi_n2
                elif der_x == 1 and der_y == 0:
                    # partial_x_psi_n1
                    partial_x_psi_n2 = (yn3 - yn1) / jacobi
                    return partial_x_psi_n2
                elif der_x == 0 and der_y == 1:
                    # partial_y_psi_n1
                    partial_y_psi_n2 = (xn1 - xn3) / jacobi
                    return partial_y_psi_n2
                else:
                    raise ParamTypeError(f'please check your input der {(der_x,der_y)} ')
            if basis_index == 2:
                if der_x == 0 and der_y == 0:
                    # psi_n1(x,y)
                    psi_n3 = (-1 * (yn2 - yn1) * (x - xn1) + (xn2 - xn1) * (y - yn1)) / jacobi
                    return psi_n3
                elif der_x == 1 and der_y == 0:
                    # partial_x_psi_n3
                    partial_x_psi_n3 = (yn1 - yn2) / jacobi
                    return partial_x_psi_n3
                elif der_x == 0 and der_y == 1:
                    # partial_y_psi_n3
                    partial_y_psi_n3 = (xn2 - xn1) / jacobi
                    return partial_y_psi_n3
                else:
                    raise ParamTypeError(f'please check your input der {(der_x,der_y)} ')

        else:

            raise ParamTypeError(f'linear basis_type not support {basis_type},please use 201 or choose other func ')

    def local_fun_2d(self, x, y, vertices, index, der):
        return self.FE_basis_local_fun_2D(x=x,
                                          y=y,
                                          vertices=vertices,
                                          basis_type=201,
                                          basis_index=index,
                                          basis_der=der
                                          )


class BasisLocalFun2DQuad:
    def __init__(self):
        self.basis_type = 202
        self.number_of_local_basis = 6
        self.number_of_boundary_cell_node = 6

    @classmethod
    def reference(cls, x, y, index, der):
        der_x = der[0]
        der_y = der[1]
        psi1 = 2*x**2 + 2*y**2+4*x*y-3*y-3*x+1
        psi2 = 2*x**2-x
        psi3 = 2*y**2 - y
        psi4 = -4*x**2 - 4 * x * y + 4 * x
        psi5 = 4*x*y
        psi6 = -4*y**2 - 4*x*y + 4 * y
        if index == 0:
            if der_x == 0 and der_y == 0:
                return psi1
            elif der_x == 1 and der_y == 0:
                return 4*x+4*y-3
            elif der_x == 0 and der_y == 1:
                return 4 * x + 4 * y - 3
            elif der_x == 1 and der_y == 1:
                return 4
            elif der_x == 2 and der_y == 0:
                return 4
            elif der_x == 0 and der_y == 2:
                return 4
            else:
                raise ParamTypeError(f"der_x:{der_x} +der_y:{der_y} ={der_x+der_y}>2, index type [int,int], ")
        elif index == 1:
            if der_x == 0 and der_y == 0:
                return psi2
            elif der_x == 1 and der_y == 0:
                return 4 * x - 1
            elif der_x == 0 and der_y == 1:
                return 0
            elif der_x == 1 and der_y == 1:
                return 0
            elif der_x == 2 and der_y == 0:
                return 4
            elif der_x == 0 and der_y == 2:
                return 0
            else:
                raise ParamTypeError(f"der_x:{der_x} +der_y:{der_y} ={der_x + der_y}>2, index type [int,int], ")
        elif index == 2:
            if der_x == 0 and der_y == 0:
                return psi3
            elif der_x == 1 and der_y == 0:
                return 0
            elif der_x == 0 and der_y == 1:
                return 4*y-1
            elif der_x == 1 and der_y == 1:
                return 0
            elif der_x == 2 and der_y == 0:
                return 4
            elif der_x == 0 and der_y == 2:
                return 4
            else:
                raise ParamTypeError(f"der_x:{der_x} +der_y:{der_y} ={der_x + der_y}>2, index type [int,int], ")
        elif index == 3:
            if der_x == 0 and der_y == 0:
                return psi4
            elif der_x == 1 and der_y == 0:
                return -8*x-4*y+4
            elif der_x == 0 and der_y == 1:
                return -4*x
            elif der_x == 1 and der_y == 1:
                return -4
            elif der_x == 2 and der_y == 0:
                return -8
            elif der_x == 0 and der_y == 2:
                return 0
            else:
                raise ParamTypeError(f"der_x:{der_x} +der_y:{der_y} ={der_x + der_y}>2, index type [int,int], ")
        elif index == 4:
            if der_x == 0 and der_y == 0:
                return psi5
            elif der_x == 1 and der_y == 0:
                return 4 * y
            elif der_x == 0 and der_y == 1:
                return 4*x
            elif der_x == 1 and der_y == 1:
                return 4
            elif der_x == 2 and der_y == 0:
                return 0
            elif der_x == 0 and der_y == 2:
                return 0
            else:
                raise ParamTypeError(f"der_x:{der_x} +der_y:{der_y} ={der_x + der_y}>2, index type [int,int], ")
        elif index == 5:
            if der_x == 0 and der_y == 0:
                return psi6
            elif der_x == 1 and der_y == 0:
                return -4*y
            elif der_x == 0 and der_y == 1:
                return -8*y-4*x+4
            elif der_x == 1 and der_y == 1:
                return -4
            elif der_x == 2 and der_y == 0:
                return 0
            elif der_x == 0 and der_y == 2:
                return -8
            else:
                raise ParamTypeError(f"der_x:{der_x} +der_y:{der_y} ={der_x + der_y}>2, index type [int,int], ")
        else:
            raise ParamTypeError(f"{index} index type int, in [0,1,2,3,4,5]")

    def local_fun_2d(self,
                     x,
                     y,
                     vertices,
                     index,
                     der
                     ):
        # vertices  对应单元的节点 [(x1,y1),(x2,y2),(x3,y3),(xc1,yc1),(xc2,yc2),(xc3,yc3)]
        # index  是对应第几个局部基函数
        # der   = [对x求导阶数，对y求导阶数]

        # 201: 2D linear
        # 202 : 2D quadratic

        xn1 = vertices[0][0]
        yn1 = vertices[0][1]
        xn2 = vertices[1][0]
        yn2 = vertices[1][1]
        xn3 = vertices[2][0]
        yn3 = vertices[2][1]
        jacobi = (xn2-xn1)*(yn3-yn1)-(xn3-xn1)*(yn2-yn1)
        x_hat = ((yn3-yn1)*(x-xn1)-(xn3-xn1)*(y-yn1))/jacobi
        y_hat = (-1*(yn2-yn1)*(x-xn1)+(xn2-xn1)*(y-yn1))/jacobi
        der_x = der[0]
        der_y = der[1]
        if der_x == 0 and der_y == 0:
            return self.reference(x_hat, y_hat, index, der=(0, 0))
        elif der_x == 1 and der_y == 0:
            partial_psi_x = self.reference(x_hat, y_hat, index, der=(1, 0))
            partial_psi_y = self.reference(x_hat, y_hat, index, der=(0, 1))
            return partial_psi_x*(yn3-yn1)/jacobi + partial_psi_y*(yn1-yn2)/jacobi
        elif der_x == 0 and der_y == 1:
            partial_psi_x = self.reference(x_hat, y_hat, index, der=(1, 0))
            partial_psi_y = self.reference(x_hat, y_hat, index, der=(0, 1))
            return partial_psi_x*(xn1-xn3)/jacobi + partial_psi_y*(xn2-xn1)/jacobi
        elif der_x == 2 and der_y == 0:
            partial_psi_xx = self.reference(x_hat, y_hat, index, der=(2, 0))
            partial_psi_xy = self.reference(x_hat, y_hat, index, der=(1, 1))
            partial_psi_yy = self.reference(x_hat, y_hat, index, der=(0, 2))
            result1 = partial_psi_xx*(yn3-yn1)**2/jacobi**2
            result2 = 2* partial_psi_xy*(yn3-yn1)*(yn1-yn2)/jacobi**2
            result3 = partial_psi_yy*(yn1-yn2)**2/jacobi**2
            return result1+result2+result3
        elif der_x == 0 and der_y == 2:
            partial_psi_xx = self.reference(x_hat, y_hat, index, der=(2, 0))
            partial_psi_xy = self.reference(x_hat, y_hat, index, der=(1, 1))
            partial_psi_yy = self.reference(x_hat, y_hat, index, der=(0, 2))
            result1 = partial_psi_xx*(xn1-xn3)**2/jacobi**2
            result2 = 2 * partial_psi_xy*(xn1-xn3)*(xn2-xn1)/jacobi**2
            result3 = partial_psi_yy*(xn2-xn1)**2/jacobi**2
            return result1 + result2 + result3
        elif der_x == 1 and der_y == 1:
            partial_psi_xx = self.reference(x_hat, y_hat, index, der=(2, 0))
            partial_psi_xy = self.reference(x_hat, y_hat, index, der=(1, 1))
            partial_psi_yy = self.reference(x_hat, y_hat, index, der=(0, 2))
            result1 = partial_psi_xx*(xn1-xn3)*(yn3-yn1)/jacobi**2
            result21 = partial_psi_xy*(xn1-xn3)*(yn1-yn2)/jacobi**2
            result22 = partial_psi_xy * (xn2 - xn1) * (yn3 - yn1) / jacobi ** 2
            result3 = partial_psi_yy*(xn2-xn1)*(yn1-yn2)/jacobi**2
            return result1 + result21+result22 + result3
        else:
            raise ParamTypeError(f"der_x:{der_x} +der_y:{der_y} ={der_x + der_y}>2, index type [int,int], ")


Fem2DLocalBasisFun = {
    'linear': BasisLocalFun2DLinear(),
    'quad': BasisLocalFun2DQuad()
}

if __name__ == '__main__':
    a=Fem2DLocalBasisFun['quad'].local_fun_2d
    for i in range(3):
        b=a(0.5,0.3,[[0,0],[0,1],[1,0]],i,(0,0))
        print(b)