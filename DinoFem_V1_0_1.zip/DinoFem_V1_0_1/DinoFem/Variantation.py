from DinoFem import DiffScheme
from DinoFem.common import get_fun

"""
变分形式类型，主要分为三种,分别对应
(Du,Dv),dt(u,v),(f,v)

FemItemStiff
FemItemTransient
FemItemLoad
"""


class FemItemStiff:
    def __init__(self,
                 coe_fun,
                 trial_der,
                 test_der,
                 trial_var,
                 test_var
                 ):
        self.coe_fun = get_fun(coe_fun)
        self.trial_der = trial_der
        self.test_der = test_der
        self.trial_var = trial_var
        self.test_var = test_var
    @property
    def express(self):
        i = str(self.trial_der)
        j = str(self.test_der)
        ss = f"< [coeff]  D_{i}{self.trial_var.name}, D_{j} {self.test_var.name} >"
        return ss


class FemItemTransient:
    def __init__(self,
                 start,
                 end,
                 steps,
                 initial_value,
                 trial_var,
                 test_var,
                 diff_scheme=DiffScheme.CrankNicolson):
        def func(*args):
            return 1
        self.coe_fun = func
        self.trial_der = [0,0]
        self.test_der = [0,0]
        self.initial_value = initial_value # 初值函数
        self.start = start  # 开始时间
        self.end = end  # 开始时间
        self.steps = steps  # 计算步数
        self.diff_scheme = diff_scheme  # 计算格式
        self.trial_var = trial_var
        self.test_var = test_var
    @property
    def express(self):
        ss = f"d< {self.trial_var.name}, {self.test_var.name} >/dt"
        return ss


class FemItemLoad:
    def __init__(self,
                 load_fun,
                 test_var
                 ):
        if callable(load_fun):

            def func(*args):
                try:
                    return load_fun(args[0],args[1],args[2])
                except:
                    return load_fun(args[0],args[1])
        else:
            def func(*args):
                return load_fun
        self.load_fun = func
        self.test_var = test_var

    @property
    def express(self):
        ss = f"< [force], {self.test_var.name} >"
        return ss


"""
创建变量，包含，对应的网格，基函数类型
"""


class Variable:
    def __init__(self, name, P, T, basis_type):
        self.name = name
        self.P = P
        self.T = T
        self.basis_type = basis_type
        self.number_of_element = len(T)
        self.number_of_nodes = len(P)


if __name__ == '__main__':
    V1 = Variable("u1",[0],[0],'1')
    V2 = Variable("u2", [0], [0], '1')
    V3 = Variable("p", [0], [0], '1')
    du1=FemItemTransient(0,1,10,1,V1,V2)
    mu1 = FemItemStiff(1,0,1,V1,V2)
    mu2 = FemItemStiff(1,1,0,V1,V2)
    lu1= FemItemLoad(1,V2)
    print(du1.express,'+',mu1.express,'+',mu2.express,'=',lu1.express)