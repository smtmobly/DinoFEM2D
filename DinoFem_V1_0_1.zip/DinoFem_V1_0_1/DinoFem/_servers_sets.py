from DinoFem.solvers.Poisson2DSolver import Poisson2DSolver
from DinoFem.solvers.Parabolic2DSolver import Parabolic2DSolver
from DinoFem.solvers.LinearElasticity2DSolver import LinearElasticity2DSolver
from DinoFem.solvers.Stokes2DSolver import Stokes2DSolver
from DinoFem.solvers.SteadyNS2DSolver import SteadyNS2DSolver
from DinoFem.solvers.UnsteadyNS2DSolver import UnsteadyNS2DSolver
from DinoFem import SolverType2D


# 输入参数函数，根据key来判断输入

# 首先定义6个输入参数字典

# poisson
# 输入
# bdy_condition_dict，
# inp_file, inp地址
# pattern,  网格类型：linear or quad
# coe_fun, 系数函数
# load_fun, 荷载函数
# var_name="T"，场名称
# 输出：
# result 字典，{场名称：每个点的场值的列表}

poisson_input = {
        "bcs_dict": None,
        "inp_file": None,
        "mesh_pattern": None,
        "coe_fun": None,
        "load_fun": None,
        "var_name": "T"
}

# 输入：
# 边界条件，
# inp_file, inp地址
# pattern,  网格类型：linear or quad
# coe_fun, 系数函数
# load_fun, 荷载函数
# start,   起始时间
# end,     结束时间
# steps,   求解步数
# initial_value, 初值
# var_name="T" 场名称
# 输出：
# result 字典，{场名称：列为每个时间节点的场值，行为对应的不同的时间节点 组成的矩阵}
parabolic_input = {
        "bcs_dict": None,
        "inp_file": None,
        "mesh_pattern": None,
        "coe_fun": None,
        "load_fun": None,
        "start": None,
        "end": None,
        "steps": None,
        "initial_value": None,
        "var_name": "T"
}

# # LinearElasticity2DSolver
# 输入：
# 边界条件，
# inp_file, inp地址
# pattern,  网格类型：linear or quad
# lam,
# mu,
# load_fun 荷载函数
#
# 输出：
# result 字典，{U：位移组成的列}
linear_elasticity_input = {
        "bcs_dict": None,
        "inp_file": None,
        "mesh_pattern": None,
        "lam": None,
        "mu": None,
        "load_fun": None,
}

# # Stokes2DSolver
# 输入：
# 边界条件，
# inp_file, inp地址
# mu,
# load_fun, 荷载函数
# p0        压力的参考值
#
# 输出：
# result 字典，{U：速度组成的列} {p:压力组成的列}

stokes_input = {
        "bcs_dict": None,
        "inp_file": None,
        "mu": None,
        "p0": None,
        "load_fun": None,
}

# # UnsteadyNS2DSolver
# 输入：  pt, mu, load_fun,p0, start, end, steps, initial_value,iterator_number=3
# 边界条件，
# inp_file, inp地址
# pattern,  网格类型：linear or quad
# mu, 系数函数
# load_fun, 荷载函数
# p0 ，压力参考值
# start,   起始时间
# end,     结束时间
# steps,   求解步数
# initial_value, 初值
# iterator_number，非线性迭代步长
# 输出：
# result 字典，{time：(u,p)}

unsteady_ns_input = {
        "bcs_dict": None,
        "inp_file": None,
        "mu": None,
        "load_fun": None,
        "p0": None,
        "start": None,
        "end": None,
        "steps": None,
        "initial_value": None,
        "iterator_number": None
}


fem2DSolvers = {
    'Poisson': Poisson2DSolver,
    'Parabolic': Parabolic2DSolver,
    'LinearElasticity': LinearElasticity2DSolver,
    'Stokes': Stokes2DSolver,
    'SteadyNS': SteadyNS2DSolver,
    'UnsteadyNS': UnsteadyNS2DSolver
}

fem2DInputs = {
        'Poisson': poisson_input,
        'Parabolic': parabolic_input,
        'LinearElasticity': linear_elasticity_input,
        'Stokes': stokes_input,
        'SteadyNS': stokes_input,
        'UnsteadyNS': unsteady_ns_input
}


class FemType:
    poisson = 'Poisson'
    parabolic = 'Parabolic'
    linear_elasticity = 'LinearElasticity'
    stokes = 'Stokes'
    steady_ns = 'SteadyNS'
    unsteady_ns = 'UnsteadyNS'


class FEM2D:
    def __init__(self, solver_name):
        self.solver = fem2DSolvers[solver_name]
        self.params = fem2DInputs[solver_name]
        

if __name__ == '__main__':
    print(fem2DInputs['Poisson']['inp_file'])

# 输出也类似。
# 解析输出，也是跟据key来解析

