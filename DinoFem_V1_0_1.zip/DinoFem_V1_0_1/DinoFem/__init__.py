from DinoFem.common import BdyType, DiffScheme, SolverType2D
