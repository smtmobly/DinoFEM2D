import sys
from DinoFem.numerical import Matrix,gauss_2d_triangle,solve,dot,copy
from DinoFem import BdyType,DiffScheme
from DinoFem.exceptions import ParamTypeError
from DinoFem.Variantation import FemItemStiff
from DinoFem.basis_fun import Fem2DLocalBasisFun


def assemble_matrix_2d(fitem):
    """

    :param fitem: 变分项类型
    :param P:  几何网格点坐标
    :param T:  几何网格单元坐标编号
    :return:  刚度矩阵
    """
    coe_fun = fitem.coe_fun
    trial_der = fitem.trial_der
    test_der = fitem.test_der
    trial_var = fitem.trial_var
    test_var = fitem.test_var
    trial_local_set = Fem2DLocalBasisFun[trial_var.basis_type]
    test_local_set = Fem2DLocalBasisFun[test_var.basis_type]
    number_of_local_basis_trial = trial_local_set.number_of_local_basis
    number_of_local_basis_test = test_local_set.number_of_local_basis
    mat = Matrix(test_var.number_of_nodes, trial_var.number_of_nodes)
    trial_fun = trial_local_set.local_fun_2d
    test_fun = test_local_set.local_fun_2d
    number_of_elements = len(test_var.T)

    def elements_vertices(n):
        i1 = test_var.T[n][0]
        i2 = test_var.T[n][1]
        i3 = test_var.T[n][2]
        return test_var.P[i1], test_var.P[i2], test_var.P[i3]

    def gauss_quad_2d_trial_test(n,basis_index_trial,basis_index_test):

        # -----------------------------
        # 定义核的导数阶数
        # basis_der_trial = 1
        # basis_der_test = 1
        # ------------------------------
        vertices = elements_vertices(n)

        def kernel(x, y):
            kernel_int_value = coe_fun(x,y)\
                    * trial_fun(x, y, vertices, basis_index_trial, trial_der)\
                    * test_fun(x, y, vertices, basis_index_test, test_der)

            return kernel_int_value
        int_value = gauss_2d_triangle(kernel, vertices)
        return int_value

    for n in range(number_of_elements):
        for alpha in range(number_of_local_basis_trial):
            for beta in range(number_of_local_basis_test):
                int_value = gauss_quad_2d_trial_test(n, alpha, beta)
                i = test_var.T[n][beta]
                j = trial_var.T[n][alpha]
                mat[i, j] = mat[i, j] + int_value
    return mat


def assemble_vector_2d(fitem):
    """

    :param fitem: 变分项目类型
    :return:  向量
    """
    load_fun = fitem.load_fun
    test_var = fitem.test_var
    test_local_set = Fem2DLocalBasisFun[test_var.basis_type]
    number_of_local_basis_test = test_local_set.number_of_local_basis
    test_fun = test_local_set.local_fun_2d
    number_of_elements = len(test_var.T)

    def points(i):
        return test_var.P[i]

    def elements_vertices(n):
        return points(ith(n, 0)), points(ith(n, 1)), points(ith(n, 2))

    def ith(n, beta):
        i = test_var.T[n][beta]
        return i

    def gauss_quad_2d_test(n,
                           basis_index_test,
                           ):
        # -----------------------------
        # 定义核的导数阶数
        # basis_der_test = 0
        # ------------------------------
        basis_der_test = [0, 0]
        vertices = elements_vertices(n)

        def kernel(x, y):
            kernel_int_value = load_fun(x, y)\
                * test_fun(x, y, vertices, basis_index_test, basis_der_test)
            return kernel_int_value
        int_value = gauss_2d_triangle(kernel, vertices)
        return int_value

    b = Matrix(test_var.number_of_nodes, 1)
    for n in range(number_of_elements):
        for beta in range(number_of_local_basis_test):
            int_value = gauss_quad_2d_test(n, beta)
            i = test_var.T[n][beta]
            b[i] = b[i] + int_value
    return b


def assemble_matrix_2d_iteration(fitem,result,begin,der):
    """

    :param fitem: 变分项类型
    :param P:  几何网格点坐标
    :param T:  几何网格单元坐标编号
    :return:  刚度矩阵
    """
    coe_fun = fitem.coe_fun
    trial_der = fitem.trial_der
    test_der = fitem.test_der
    trial_var = fitem.trial_var
    test_var = fitem.test_var
    trial_local_set = Fem2DLocalBasisFun[trial_var.basis_type]
    test_local_set = Fem2DLocalBasisFun[test_var.basis_type]
    number_of_local_basis_trial = trial_local_set.number_of_local_basis
    number_of_local_basis_test = test_local_set.number_of_local_basis
    mat = Matrix(test_var.number_of_nodes, trial_var.number_of_nodes)
    trial_fun = trial_local_set.local_fun_2d
    test_fun = test_local_set.local_fun_2d
    number_of_elements = len(test_var.T)

    def elements_vertices(n):
        i1 = test_var.T[n][0]
        i2 = test_var.T[n][1]
        i3 = test_var.T[n][2]
        return test_var.P[i1], test_var.P[i2], test_var.P[i3]

    def gauss_quad_2d_trial_test(n,basis_index_trial,basis_index_test):

        # -----------------------------
        # 定义核的导数阶数
        # basis_der_trial = 1
        # basis_der_test = 1
        # ------------------------------
        vertices = elements_vertices(n)

        def fun(x, y):
            int_value = 0
            for alpha in range(number_of_local_basis_test):
                i = test_var.T[n][alpha]
                int_value += result[begin + i] * test_fun(x, y, vertices, alpha, der)
            return int_value

        def kernel(x, y):
            kernel_int_value = fun(x,y)\
                    * trial_fun(x, y, vertices, basis_index_trial, trial_der)\
                    * test_fun(x, y, vertices, basis_index_test, test_der)

            return kernel_int_value
        int_value = gauss_2d_triangle(kernel, vertices)
        return int_value

    for n in range(number_of_elements):
        for alpha in range(number_of_local_basis_trial):
            for beta in range(number_of_local_basis_test):
                int_value = gauss_quad_2d_trial_test(n, alpha, beta)
                i = test_var.T[n][beta]
                j = trial_var.T[n][alpha]
                mat[i, j] = mat[i, j] + int_value
    return mat


def assemble_vector_2d_iteration(fitem,result,begin1,der1,begin2,der2):
    """

    :param fitem: 变分项目类型
    :return:  向量
    """
    load_fun = fitem.load_fun
    test_var = fitem.test_var
    test_local_set = Fem2DLocalBasisFun[test_var.basis_type]
    number_of_local_basis_test = test_local_set.number_of_local_basis
    test_fun = test_local_set.local_fun_2d
    number_of_elements = len(test_var.T)

    def points(i):
        return test_var.P[i]

    def elements_vertices(n):
        return points(ith(n, 0)), points(ith(n, 1)), points(ith(n, 2))

    def ith(n, beta):
        i = test_var.T[n][beta]
        return i

    def gauss_quad_2d_test(n,
                           basis_index_test,
                           ):
        # -----------------------------
        # 定义核的导数阶数
        # basis_der_test = 0
        # ------------------------------
        basis_der_test = [0, 0]
        vertices = elements_vertices(n)
        def fun(x, y):
            int_value1 = 0
            for alpha in range(number_of_local_basis_test):
                i = test_var.T[n][alpha]
                int_value1 += result[begin1 + i] * test_fun(x, y, vertices, alpha, der1)
            int_value2 = 0
            for alpha in range(number_of_local_basis_test):
                i = test_var.T[n][alpha]
                int_value2 += result[begin2 + i] * test_fun(x, y, vertices, alpha, der2)
            return int_value1*int_value2

        def kernel(x, y):
            kernel_int_value = fun(x, y)\
                * test_fun(x, y, vertices, basis_index_test, basis_der_test)
            return kernel_int_value
        int_value = gauss_2d_triangle(kernel, vertices)
        return int_value

    b = Matrix(test_var.number_of_nodes, 1)
    for n in range(number_of_elements):
        for beta in range(number_of_local_basis_test):
            int_value = gauss_quad_2d_test(n, beta)
            i = test_var.T[n][beta]
            b[i] = b[i] + int_value
    return b



def treat_dirichlet_boundary(P,
                             BN,
                             boundaries_name,
                             boundary_type_dict,
                             boundary_value_dict,
                             mat,
                             b):
    """

    :param P: 输入边界对应的点坐标序列
    :param BN: 边界矩阵
    :param boundaries_name: 边界序号及名称的对应
    :param boundary_type_dict: 边界名称与边界类型的字典
    :param boundary_value_dict: 边界名称与边界函数的字典
    :param mat:   需要处理边界的矩阵
    :param b:   需要处理的向量矩阵
    :return:   返回mat及b
    """
    number_of_boundary_nodes = len(BN)

    def boundary_nodes_type(k):
        return BN[k][0]

    def boundary_type(k):
        if k < 0:
            return k
        return boundary_type_dict[boundaries_name[k]]

    def boundary_value(k):
        return boundary_value_dict[boundaries_name[k]]

    def boundary_nodes_indexes(k):
        return BN[k][1]

    def points(i):
        return P[i]

    for k in range(number_of_boundary_nodes):
        boundary_index = boundary_nodes_type(k)

        if BdyType.isDirichlet(boundary_type(boundary_index)):
            g = boundary_value(boundary_index)

            i = boundary_nodes_indexes(k)

            mat[i, :] = 0
            mat[i, i] = 1
            b[i] = g(points(i)[0], points(i)[1])
    return copy(mat), copy(b)


def treat_dirichlet_boundary_multivars(P,
                             BN,
                             boundaries_name,
                             boundary_type_dict,
                             boundary_value_dict,
                             mat,
                             b):
    """

    :param P: 输入边界对应的点坐标序列
    :param BN: 边界矩阵
    :param boundaries_name: 边界序号及名称的对应
    :param boundary_type_dict: 边界名称与边界类型的字典
    :param boundary_value_dict: 边界名称与边界函数的字典
    :param mat:   需要处理边界的矩阵
    :param b:   需要处理的向量矩阵
    :return:   返回mat及b
    """
    number_of_boundary_nodes = len(BN)

    def boundary_nodes_type(k):
        return BN[k][0]

    def boundary_type(k):
        if k < 0:
            return k
        return boundary_type_dict[boundaries_name[k]]

    def boundary_value(k):
        return boundary_value_dict[boundaries_name[k]]

    def boundary_nodes_indexes(k):
        return BN[k][1]

    def points(i):
        return P[i]

    Nb = len(P)
    for k in range(number_of_boundary_nodes):
        boundary_index = boundary_nodes_type(k)

        if BdyType.isDirichlet(boundary_type(boundary_index)):
            g1 = boundary_value(boundary_index)[0]
            g2 = boundary_value(boundary_index)[1]

            i = boundary_nodes_indexes(k)

            mat[i, :] = 0
            mat[i, i] = 1
            b[i] = g1(points(i)[0], points(i)[1])
            mat[Nb + i, :] = 0
            mat[Nb + i, Nb + i] = 1
            b[Nb + i] = g2(points(i)[0], points(i)[1])
    return copy(mat), copy(b)


def assemble_matrix_2d_transient(fitem,t):
    """

    :param fitem: 变分项类型
    :param P:  几何网格点坐标
    :param T:  几何网格单元坐标编号
    :return:  刚度矩阵
    """
    coe_fun = fitem.coe_fun
    trial_der = fitem.trial_der
    test_der = fitem.test_der
    trial_var = fitem.trial_var
    test_var = fitem.test_var
    trial_local_set = Fem2DLocalBasisFun[trial_var.basis_type]
    test_local_set = Fem2DLocalBasisFun[test_var.basis_type]
    number_of_local_basis_trial = trial_local_set.number_of_local_basis
    number_of_local_basis_test = test_local_set.number_of_local_basis
    mat = Matrix(test_var.number_of_nodes, trial_var.number_of_nodes)
    trial_fun = trial_local_set.local_fun_2d
    test_fun = test_local_set.local_fun_2d
    number_of_elements = len(test_var.T)

    def elements_vertices(n):
        i1 = test_var.T[n][0]
        i2 = test_var.T[n][1]
        i3 = test_var.T[n][2]
        return test_var.P[i1], test_var.P[i2], test_var.P[i3]

    def gauss_quad_2d_trial_test(n,basis_index_trial,basis_index_test):

        # -----------------------------
        # 定义核的导数阶数
        # basis_der_trial = 1
        # basis_der_test = 1
        # ------------------------------
        vertices = elements_vertices(n)

        def kernel(x, y):
            kernel_int_value = coe_fun(x,y,t)\
                    * trial_fun(x, y, vertices, basis_index_trial, trial_der)\
                    * test_fun(x, y, vertices, basis_index_test, test_der)

            return kernel_int_value
        int_value = gauss_2d_triangle(kernel, vertices)
        return int_value

    for n in range(number_of_elements):
        for alpha in range(number_of_local_basis_trial):
            for beta in range(number_of_local_basis_test):
                int_value = gauss_quad_2d_trial_test(n, alpha, beta)
                i = test_var.T[n][beta]
                j = trial_var.T[n][alpha]
                mat[i, j] = mat[i, j] + int_value
    return mat


def assemble_vector_2d_transient(fitem,t):
    """

    :param fitem: 变分项目类型
    :return:  向量
    """
    load_fun = fitem.load_fun
    test_var = fitem.test_var
    test_local_set = Fem2DLocalBasisFun[test_var.basis_type]
    number_of_local_basis_test = test_local_set.number_of_local_basis
    test_fun = test_local_set.local_fun_2d
    number_of_elements = len(test_var.T)

    def points(i):
        return test_var.P[i]

    def elements_vertices(n):
        return points(ith(n, 0)), points(ith(n, 1)), points(ith(n, 2))

    def ith(n, beta):
        i = test_var.T[n][beta]
        return i

    def gauss_quad_2d_test(n,
                           basis_index_test
                           ):
        # -----------------------------
        # 定义核的导数阶数
        # basis_der_test = 0
        # ------------------------------
        basis_der_test = [0, 0]
        vertices = elements_vertices(n)

        def kernel(x, y):
            kernel_int_value = load_fun(x, y, t)\
                * test_fun(x, y, vertices, basis_index_test, basis_der_test)
            return kernel_int_value
        int_value = gauss_2d_triangle(kernel, vertices)
        return int_value

    b = Matrix(test_var.number_of_nodes, 1)
    for n in range(number_of_elements):
        for beta in range(number_of_local_basis_test):
            int_value = gauss_quad_2d_test(n, beta)
            i = test_var.T[n][beta]
            b[i] = b[i] + int_value
    return b


def treat_dirichlet_boundary_transient(P,
                                       BN,
                                       boundaries_name,
                                       boundary_type_dict,
                                       boundary_value_dict,
                                       mat,
                                       b,
                                       t):
    """

    :param P: 输入边界对应的点坐标序列
    :param BN: 边界矩阵
    :param boundaries_name: 边界序号及名称的对应
    :param boundary_type_dict: 边界名称与边界类型的字典
    :param boundary_value_dict: 边界名称与边界函数的字典
    :param mat:   需要处理边界的矩阵
    :param b:   需要处理的向量矩阵
    :return:   返回mat及b
    """
    number_of_boundary_nodes = len(BN)

    def boundary_nodes_type(k):
        return BN[k][0]

    def boundary_type(k):
        if k < 0:
            return k
        return boundary_type_dict[boundaries_name[k]]

    def boundary_value(k):
        return boundary_value_dict[boundaries_name[k]]

    def boundary_nodes_indexes(k):
        return BN[k][1]

    def points(i):
        return P[i]

    for k in range(number_of_boundary_nodes):
        boundary_index = boundary_nodes_type(k)

        if BdyType.isDirichlet(boundary_type(boundary_index)):
            g = boundary_value(boundary_index)

            i = boundary_nodes_indexes(k)

            mat[i, :] = 0
            mat[i, i] = 1
            b[i] = g(points(i)[0], points(i)[1],t)
    return mat, b


def treat_dirichlet_boundary_vector_transient(P,
                                       BN,
                                       boundaries_name,
                                       boundary_type_dict,
                                       boundary_value_dict,
                                       b,
                                       t):
    """

    :param P: 输入边界对应的点坐标序列
    :param BN: 边界矩阵
    :param boundaries_name: 边界序号及名称的对应
    :param boundary_type_dict: 边界名称与边界类型的字典
    :param boundary_value_dict: 边界名称与边界函数的字典
    :param mat:   需要处理边界的矩阵
    :param b:   需要处理的向量矩阵
    :return:   返回mat及b
    """
    number_of_boundary_nodes = len(BN)

    def boundary_nodes_type(k):
        return BN[k][0]

    def boundary_type(k):
        if k < 0:
            return k
        return boundary_type_dict[boundaries_name[k]]

    def boundary_value(k):
        return boundary_value_dict[boundaries_name[k]]

    def boundary_nodes_indexes(k):
        return BN[k][1]

    def points(i):
        return P[i]

    for k in range(number_of_boundary_nodes):
        boundary_index = boundary_nodes_type(k)

        if BdyType.isDirichlet(boundary_type(boundary_index)):
            g = boundary_value(boundary_index)

            i = boundary_nodes_indexes(k)
            b[i] = g(points(i)[0], points(i)[1],t)
    return b


def get_solver_fun_in_element(result,
                             begin,
                             index,
                             P,
                             T,
                             basis_set,
                             der
                             ):
    """
    :param result:解向量
    :param begin: 起始位置
    :param index: 单元编号
    :param P: 点列
    :param T: 单元编号
    :param basis_set: 基函数集合
    :param der: 导数指标
    :return: 在该单元上的解的近似函数表达
    """
    num_basis = basis_set.number_of_local_basis
    trial_fun = basis_set.local_fun_2d

    def elements_vertices(n):
        i1 = T[n][0]
        i2 = T[n][1]
        i3 = T[n][2]
        return P[i1], P[i2], P[i3]

    vertices = elements_vertices(index)

    def fun(x,y):
        int_value = 0
        for alpha in num_basis:
            i = T[alpha,index]
            int_value += result[begin+i]*trial_fun(x, y, vertices, alpha, der)
        return int_value
    return fun

