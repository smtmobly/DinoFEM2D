from enum import Enum
from DinoFem.exceptions import ParamTypeError


class BdyType(Enum):
    Dirichlet = -1
    ZeroGradient = -2
    NonZeroGradient = -3

    @classmethod
    def isDirichlet(cls,a):
        if a.value == cls.Dirichlet.value:
            return True
        else:
            return False


class DiffScheme(Enum):
    EulerBackward = 1
    CrankNicolson = 0.5


def get_fun(load_fun,dim=2):
    if callable(load_fun):
        if dim == 2:
            def func(*args):
                try:
                    return load_fun(args[0], args[1], args[2])
                except:
                    return load_fun(args[0], args[1])
        elif dim ==3:
            def func(*args):
                try:
                    return load_fun(args[0], args[1], args[2],args[3])
                except:
                    return load_fun(args[0], args[1],args[2])
        else:
            raise ParamTypeError(f'Parameter wrong,{dim}?2 or 3')
    else:
        def func(*args):
            return load_fun
    return func


def time_tag(time):
    time = time.replace(".","")
    if len(time)==1:
        time = "000"+time
    elif len(time)==2:
        time = "00" + time
    elif len(time) == 3:
        time = "0" + time
    elif len(time) == 4:
        pass
    return time


def get_sorted_list(d, reverse=True):
    return sorted(d.items(), key=lambda x: x[1], reverse=reverse)


class SolverType2D(Enum):
    Poisson = 1
    Parabolic = 2
    LinearElasticity = 3
    Stokes = 4
    SteadyNS = 5
    UnsteadyNS = 6

    @classmethod
    def isPoisson(cls, a1):
        if a1.value == cls.Poisson.value:
            return True
        else:
            return False

    @classmethod
    def isParabolic(cls, a1):
        if a1.value == cls.Parabolic.value:
            return True
        else:
            return False

    @classmethod
    def isLinearElasticity(cls, a1):
        if a1.value == cls.LinearElasticity.value:
            return True
        else:
            return False

    @classmethod
    def isStokes(cls, a1):
        if a1.value == cls.Stokes.value:
            return True
        else:
            return False

    @classmethod
    def isSteadyNS(cls, a1):
        if a1.value == cls.SteadyNS.value:
            return True
        else:
            return False

    @classmethod
    def isUnsteadyNS(cls, a1):
        if a1.value == cls.UnsteadyNS.value:
            return True
        else:
            return False


if __name__ == '__main__':
    print(SolverType2D['Poisson'])
    print(SolverType2D.Poisson.value)




