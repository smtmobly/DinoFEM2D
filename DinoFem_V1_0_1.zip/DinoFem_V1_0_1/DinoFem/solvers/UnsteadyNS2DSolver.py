from DinoFem.Variantation import FemItemLoad,FemItemStiff,Variable,FemItemTransient
from DinoFem.numerical import solve,dot,Matrix,copy,concatenate,array
from DinoFem.FemOPS import assemble_matrix_2d,assemble_vector_2d,treat_dirichlet_boundary_multivars
from DinoFem.FemOPS import assemble_matrix_2d_iteration,assemble_vector_2d_iteration
from DinoFem.FemOPS import assemble_vector_2d_transient


class UnsteadyNS2DSolver:
    def __init__(self, pt, mu, load_fun,p0, start, end, steps, initial_value,iterator_number=3):
        print("--------------------------- FEM-Unsteady Navier-Stokes Equations ------------------")
        print("-----------------------------------------------------------------------")
        self.pt = pt
        print("--------------Variable setting -----------------")
        self.u1 = Variable("u1", self.pt.P, self.pt.T, self.pt.pattern)
        self.p = Variable("p", self.pt.P_mesh, self.pt.T_mesh, "linear")
        self.Dt = FemItemTransient(start, end, steps, initial_value, trial_var=self.u1, test_var=self.u1)
        print("--------------Variation setting -----------------")
        s1 = FemItemStiff(coe_fun=mu, test_der=[1, 0], trial_der=[1, 0], trial_var=self.u1,test_var=self.u1)
        s2 = FemItemStiff(coe_fun=mu, test_der=[0, 1], trial_der=[0, 1], trial_var=self.u1,test_var=self.u1)
        s3 = FemItemStiff(coe_fun=mu, test_der=[1, 0], trial_der=[0, 1], trial_var=self.u1,test_var=self.u1)
        # s4 = FemItemStiff(coe_fun=mu, test_der=[1, 0], trial_der=[1, 0], trial_fun_type='quad', test_fun_type='quad')
        s5 = FemItemStiff(coe_fun=-1, test_der=[1, 0], trial_der=[0, 0], trial_var=self.p,test_var=self.u1)
        s6 = FemItemStiff(coe_fun=-1, test_der=[0, 1], trial_der=[0, 0], trial_var=self.p,test_var=self.u1)
        # s7 = FemItemStiff(coe_fun=mu, test_der=[1, 0], trial_der=[1, 0], trial_fun_type='quad', test_fun_type='quad')
        # s8 = FemItemStiff(coe_fun=mu, test_der=[1, 0], trial_der=[1, 0], trial_fun_type='quad', test_fun_type='quad')
        # 迭代非线性部分的线性化矩阵
        self.l1 = FemItemStiff(coe_fun=1, trial_der=[0, 0], test_der=[0, 0], trial_var=self.u1,test_var=self.u1)
        self.l2 = FemItemStiff(coe_fun=1, trial_der=[1, 0], test_der=[0, 0], trial_var=self.u1, test_var=self.u1)
        self.l3 = FemItemStiff(coe_fun=1, trial_der=[0, 1], test_der=[0, 0], trial_var=self.u1, test_var=self.u1)
        self.lf = FemItemLoad(load_fun=1, test_var=self.u1)
        self.f1 = FemItemLoad(load_fun=load_fun[0], test_var=self.u1)
        self.f2 = FemItemLoad(load_fun=load_fun[1], test_var=self.u1)
        # 基本参数
        self.u_number = self.u1.number_of_nodes
        self.iteration_num = iterator_number
        self.p_number = self.p.number_of_nodes
        self.p0 = p0
        self.dt = (self.Dt.end-self.Dt.start)/self.Dt.steps
        # 矩阵准备
        print("--------------Assemble Matrix  -----------------")
        #
        a11 = 2*assemble_matrix_2d(s1) + assemble_matrix_2d(s2)
        a12 = assemble_matrix_2d(s3)
        a13 = assemble_matrix_2d(s5)
        a21 = a12.transpose()
        a22 = 2*assemble_matrix_2d(s2) + assemble_matrix_2d(s1)
        a23 = assemble_matrix_2d(s6)
        a31 = a13.transpose()
        a32 = a23.transpose()
        a33 = Matrix(self.p_number,self.p_number)
        #
        c1 = concatenate((a11, a12, a13), axis=1)
        c2 = concatenate((a21, a22, a23), axis=1)
        c3 = concatenate((a31, a32, a33), axis=1)
        #
        self.O1 = Matrix(self.p_number,self.p_number)
        self.O2 = Matrix(self.u_number,self.p_number)
        self.O3 = Matrix(self.u_number,self.p_number)
        self.OB = Matrix(self.p_number, 1)
        # 基本矩阵
        self.Mat = concatenate((c1, c2, c3))

        Me = assemble_matrix_2d(self.Dt)
        M1 = concatenate((Me,Matrix(self.u_number,self.u_number),self.O2),axis=1)
        M2 = concatenate((Matrix(self.u_number, self.u_number),Me, self.O2),axis=1)
        M3 = concatenate((self.O2.transpose(), self.O2.transpose(), self.O1),axis=1)
        self.Mass = concatenate((M1, M2, M3))
        print("-----------------------------------------------------------------------")
        self.result = {}
        self.u_0 = Matrix(self.u_number*2+self.p_number, 1)

    def initial_u_0(self):
        ivalue1 = self.Dt.initial_value[0]
        ivalue2 = self.Dt.initial_value[1]
        for i in range(self.u_number):
            self.u_0[i] = ivalue1(self.pt.P[i][0], self.pt.P[i][1])
            self.u_0[self.u_number+i] = ivalue2(self.pt.P[i][0], self.pt.P[i][1])
        for i in range(self.p_number):
            self.u_0[2*self.u_number+i] = self.p0(self.pt.P_mesh[i][0], self.pt.P_mesh[i][1])

    def assemble_b(self, t):
        b1 = assemble_vector_2d_transient(self.f1, t)
        b2 = assemble_vector_2d_transient(self.f2, t)
        b3 = Matrix(self.p_number, 1)
        b = concatenate((b1, b2, b3))
        return b

    def set_pressure_0(self, A, b, p0):
        # 为压力设置初始值
        n = 2*self.u_number
        A[n, :] = 0
        A[n, n] = 1
        b[n] = p0
        return A, b

    def iteration_steps(self,u_m,t):
        u_number = self.u1.number_of_nodes
        u_old = copy(u_m)
        O1 = self.O1
        O2 = self.O2
        O3 = self.O3
        OB = self.OB
        u_new=None
        # 构筑迭代格式
        for l in range(self.iteration_num):
            print(f"---- iteration: iterNum {l} -----")
            AN1 = assemble_matrix_2d_iteration(self.l1, u_old, 0, [1, 0])
            AN2 = assemble_matrix_2d_iteration(self.l2, u_old, 0, [0, 0])
            AN3 = assemble_matrix_2d_iteration(self.l3, u_old, u_number, [0, 0])
            AN4 = assemble_matrix_2d_iteration(self.l1, u_old, 0, [0, 1])
            AN5 = assemble_matrix_2d_iteration(self.l1, u_old, u_number, [1, 0])
            AN6 = assemble_matrix_2d_iteration(self.l1, u_old, u_number, [0, 1])
            A_Nonlinear1 = concatenate((AN1+AN2+AN3,AN4,O2),axis=1)
            A_Nonlinear2 = concatenate((AN5,AN6+AN2+AN3,O3), axis=1)
            A_Nonlinear3 = concatenate((O2.transpose(), O3.transpose(), O1), axis=1)
            A_Nonlinear = concatenate((A_Nonlinear1,A_Nonlinear2,A_Nonlinear3))

            BN1 = assemble_vector_2d_iteration(self.lf, u_old, begin1=0, begin2=0, der1=[0, 0],
                                               der2=[1, 0])
            BN2 = assemble_vector_2d_iteration(self.lf, u_old, begin1=u_number, begin2= 0, der1=[0, 0],
                                               der2=[0, 1])
            BN3 = assemble_vector_2d_iteration(self.lf, u_old, begin1=0, begin2=u_number, der1=[0, 0],
                                               der2=[1, 0])
            BN4 = assemble_vector_2d_iteration(self.lf, u_old, begin1=u_number, begin2=u_number, der1=[0, 0],
                                               der2=[0, 1])
            BN = concatenate((BN1+BN2,BN3+BN4,OB))
            A_l = 1/self.dt*self.Mass+self.Mat+A_Nonlinear
            b_l = self.assemble_b(t)+BN+1/self.dt*dot(self.Mass,u_m)
            # 处理边界条件
            A_l, b_l = treat_dirichlet_boundary_multivars(
                self.pt.P,
                self.pt.BN,
                self.pt.boundaries_name,
                self.pt.boundary_type_dict,
                self.pt.boundary_value_dict,
                A_l,
                b_l
            )
            # 压力设置参考值
            p0 = self.p0(self.pt.P_mesh[0][0], self.pt.P_mesh[0][1],t)
            n=2*self.u1.number_of_nodes
            A_l[n, :] = 0
            A_l[n, n] = 1
            b_l[n] = p0
            u_new = solve(A_l,b_l)
            u_old = u_new
        return u_new

    def save_result(self,t,u):
        name = str(round(t, 3))
        v = [(u[i], u[self.u_number + i]) for i in range(self.u_number)]

        p = [u[2 * self.u_number + i] for i in range(self.p_number)]

        self.result[name] = (v, p)

    def solve(self):
        steps = self.Dt.steps
        start = self.Dt.start
        print("-----Initializing---------")
        # 设定初值矩阵
        self.initial_u_0()

        self.save_result(start,self.u_0)
        u_old = self.u_0
        for m in range(steps):

            tmp1 = start+(m+1)*self.dt
            print(f"-----solving Time t = {tmp1}---------")
            u_new = self.iteration_steps(u_old,tmp1)
            self.save_result(tmp1, u_new)
            u_old = u_new

        print("---- U saved! -----")

        print("---- p saved! -----")
        print("--------------------------- FEM  Unsteady-Navier-Stokes Equations Finished! ------------------")
