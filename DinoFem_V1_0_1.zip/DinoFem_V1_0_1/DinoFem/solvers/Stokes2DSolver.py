from DinoFem.Variantation import FemItemLoad,FemItemStiff,Variable,FemItemTransient
from DinoFem.numerical import solve,dot,Matrix,copy,concatenate,array
from DinoFem.FemOPS import assemble_matrix_2d,assemble_vector_2d,treat_dirichlet_boundary_multivars


class Stokes2DSolver:
    def __init__(self, pt,mu,load_fun,p0):
        self.pt = pt
        self.u1 = Variable("u1", self.pt.P, self.pt.T, self.pt.pattern)
        self.u2 = Variable("u2", self.pt.P, self.pt.T, self.pt.pattern)
        self.p = Variable("p", self.pt.P_mesh, self.pt.T_mesh, "linear")
        s1 = FemItemStiff(coe_fun=mu, test_der=[1, 0], trial_der=[1, 0], trial_var=self.u1,test_var=self.u1)
        s2 = FemItemStiff(coe_fun=mu, test_der=[0, 1], trial_der=[0, 1], trial_var=self.u1,test_var=self.u1)
        s3 = FemItemStiff(coe_fun=mu, test_der=[1, 0], trial_der=[0, 1], trial_var=self.u1,test_var=self.u1)
        # s4 = FemItemStiff(coe_fun=mu, test_der=[1, 0], trial_der=[1, 0], trial_fun_type='quad', test_fun_type='quad')
        s5 = FemItemStiff(coe_fun=-1, test_der=[1, 0], trial_der=[0, 0], trial_var=self.p,test_var=self.u1)
        s6 = FemItemStiff(coe_fun=-1, test_der=[0, 1], trial_der=[0, 0], trial_var=self.p,test_var=self.u1)
        # s7 = FemItemStiff(coe_fun=mu, test_der=[1, 0], trial_der=[1, 0], trial_fun_type='quad', test_fun_type='quad')
        # s8 = FemItemStiff(coe_fun=mu, test_der=[1, 0], trial_der=[1, 0], trial_fun_type='quad', test_fun_type='quad')

        f1 = FemItemLoad(load_fun=load_fun[0], test_var=self.u1)
        f2 = FemItemLoad(load_fun=load_fun[1], test_var=self.u1)
        a11 = 2*assemble_matrix_2d(s1) + assemble_matrix_2d(s2)
        a12 = assemble_matrix_2d(s3)
        a13 = assemble_matrix_2d(s5)
        a21 = a12.transpose()
        a22 = 2*assemble_matrix_2d(s2) + assemble_matrix_2d(s1)
        a23 = assemble_matrix_2d(s6)
        a31 = a13.transpose()
        a32 = a23.transpose()
        # 处理p
        a33 = Matrix(self.p.number_of_nodes,self.p.number_of_nodes)

        c1 = concatenate((a11, a12, a13), axis=1)
        c2 = concatenate((a21, a22, a23), axis=1)
        c3 = concatenate((a31, a32, a33), axis=1)
        self.Mat = concatenate((c1, c2, c3))
        b1 = assemble_vector_2d(f1)
        b2 = assemble_vector_2d(f2)
        b3 = Matrix(self.p.number_of_nodes,1)
        self.b = concatenate((b1, b2, b3))
        # 为压力设置初始值
        n=2*self.u1.number_of_nodes
        self.Mat[n, :] = 0
        self.Mat[n, n] = 1
        self.b[n] = p0
        self.Mat, self.b = treat_dirichlet_boundary_multivars(
            self.pt.P,
            self.pt.BN,
            self.pt.boundaries_name,
            self.pt.boundary_type_dict,
            self.pt.boundary_value_dict,
            self.Mat,
            self.b
        )

        print("--------------------------- FEM-Stokes Equations ------------------")
        print("-----------------------------------------------------------------------")

        print("---- Solving -----")

        print("-----------------------------------------------------------------------")
        self.result = {}

    def solve(self):
        u = solve(self.Mat, self.b)
        print(u.shape)
        print("---- Saving U,p -----")
        nn = self.u1.number_of_nodes
        v = [(u[i],u[nn+i]) for i in range(nn)]
        p = [u[2*nn+i] for i in range(self.p.number_of_nodes)]
        self.result['U'] = v
        self.result['p'] = p
        print("---- U saved! -----")

        print("---- p saved! -----")
        print("--------------------------- FEM-Stokes Equations Finished! ------------------")
