from DinoFem.Variantation import FemItemLoad,FemItemStiff,Variable,FemItemTransient
from DinoFem.numerical import solve,dot,Matrix,copy
from DinoFem.FemOPS import assemble_matrix_2d,assemble_vector_2d_transient,\
    treat_dirichlet_boundary_transient


class Parabolic2DSolver:
    def __init__(self, pt,coe_fun,load_fun,start,end,steps,initial_value,var_name="T"):
        self.pt = pt

        self.var = Variable(var_name, self.pt.P, self.pt.T, self.pt.pattern)
        self.Dt = FemItemTransient(start,end,steps,initial_value,trial_var=self.var,test_var=self.var)
        s1 = FemItemStiff(
            coe_fun=coe_fun,
            trial_der=[1, 0],
            test_der=[1, 0],
            trial_var=self.var,
            test_var=self.var
                          )
        s2 = FemItemStiff(
            coe_fun=coe_fun,
            trial_der=[0, 1],
            test_der=[0, 1],
            trial_var=self.var,
            test_var=self.var
                          )
        self.f= FemItemLoad(load_fun=load_fun,test_var=self.var)

        express = self.Dt.express+'+'+s1.express+'+'+s2.express+'='+self.f.express
        print("---------------------------FEM-Parabolic-2D------------------")
        print("Variation".upper())
        print(express)
        self.dt = (end - start) / steps  # 步长
        M = assemble_matrix_2d(self.Dt)
        A = assemble_matrix_2d(s1)+assemble_matrix_2d(s2)
        self.number_of_nodes = self.var.number_of_nodes
        self.theta = self.Dt.diff_scheme.value
        self.A_hat = (1 / self.dt) * M + self.theta*A
        self.A_fixed = (1 / self.dt) * M - (1-self.theta)*A
        self.sol = Matrix(self.number_of_nodes, steps+1)

        self.result = {self.var.name: self.sol}

    def solve(self):
        print("---------------------------FEM-Solving------------------")
        A_hat = copy(self.A_hat)
        #
        # 基本数据处理
        dt = self.dt  # 步长
        initial_value = self.Dt.initial_value  # 初值
        theta = self.theta  # 差分形式
        start = self.Dt.start
        steps = self.Dt.steps
        bm = assemble_vector_2d_transient(self.f, start)
        if callable(initial_value):
            for i in range(self.number_of_nodes):
                self.sol[i,0] = initial_value(self.pt.P[i][0],self.pt.P[i][1])
        else:
            self.sol[:,0] = initial_value

        xm = Matrix(self.number_of_nodes, 1)

        for m in range(steps):
            tmp1 = start+(m+1)*dt
            name = str(round(tmp1, 3))
            print(f"solving  time step={name}")
            bmp1 = assemble_vector_2d_transient(self.f, tmp1)

            xm[:, 0] = self.sol[:, m]
            b_hat = theta * bmp1 + (1 - theta) * bm + dot(self.A_fixed, xm)

            A_hat, b_hat = treat_dirichlet_boundary_transient(
                self.pt.P,
                self.pt.BN,
                self.pt.boundaries_name,
                self.pt.boundary_type_dict,
                self.pt.boundary_value_dict,
                A_hat,
                b_hat,
                tmp1
            )
            x = solve(A_hat, b_hat)
            self.sol[:, m + 1] = x[:, 0]
            bm = copy(bmp1)
        print("----------------------------Solved !------------------")





