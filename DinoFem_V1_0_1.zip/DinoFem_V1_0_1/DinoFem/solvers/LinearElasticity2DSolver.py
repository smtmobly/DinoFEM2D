from DinoFem.Variantation import FemItemLoad,FemItemStiff,Variable,FemItemTransient
from DinoFem.numerical import solve,dot,Matrix,copy,concatenate
from DinoFem.FemOPS import assemble_matrix_2d,assemble_vector_2d,treat_dirichlet_boundary_multivars


class LinearElasticity2DSolver:
    def __init__(self, pt,lam,mu,load_fun,var_name='U'):
        """

        :param pt:  网格矩阵,边界条件，也是一个列表 [g1,g2]
        :param lam: lambda 模量
        :param mu:  mu 模量
        :param load_fun:  右端源项 【f1,f2】,f1,f2必须是f(x,y,t)的定义形式
        :param var_name:  变量名称
        """
        self.pt = pt
        self.u1 = Variable("u1", self.pt.P, self.pt.T, self.pt.pattern)
        self.u2 = Variable("u2", self.pt.P, self.pt.T, self.pt.pattern)
        s1 = FemItemStiff(coe_fun=lam, test_der=[1, 0], trial_der=[1, 0],trial_var=self.u1,test_var=self.u2)
        s2 = FemItemStiff(coe_fun=mu, test_der=[1, 0], trial_der=[1, 0],trial_var=self.u1,test_var=self.u2)
        #
        s3= FemItemStiff(coe_fun=mu, test_der=[0, 1], trial_der=[0, 1],trial_var=self.u1,test_var=self.u2)
        s4 = FemItemStiff(coe_fun=lam, test_der=[0, 1], trial_der=[1, 0],trial_var=self.u1,test_var=self.u2)
        #
        s5 = FemItemStiff(coe_fun=mu, test_der=[1, 0], trial_der=[0, 1],trial_var=self.u1,test_var=self.u2)
        s6 = FemItemStiff(coe_fun=lam, test_der=[1, 0], trial_der=[0, 1],trial_var=self.u1,test_var=self.u2)
        s7 = FemItemStiff(coe_fun=mu, test_der=[0, 1], trial_der=[1, 0],trial_var=self.u1,test_var=self.u2)
        s8 = FemItemStiff(coe_fun=lam, test_der=[0, 1], trial_der=[0, 1],trial_var=self.u1,test_var=self.u2)
        a11 = assemble_matrix_2d(s1) + 2*assemble_matrix_2d(s2) + assemble_matrix_2d(s3)
        a12 = assemble_matrix_2d(s4)+assemble_matrix_2d(s5)
        a21 = assemble_matrix_2d(s6) + assemble_matrix_2d(s7)
        a22 = assemble_matrix_2d(s8) + 2 * assemble_matrix_2d(s3) + assemble_matrix_2d(s2)
        c1 = concatenate((a11, a12), axis=1)
        c2 = concatenate((a21, a22), axis=1)
        self.mat = concatenate((c1, c2))
        f1= FemItemLoad(load_fun=load_fun[0],test_var=self.u1)
        f2 = FemItemLoad(load_fun=load_fun[1], test_var=self.u2)
        b1= assemble_vector_2d(f1)
        b2 = assemble_vector_2d(f2)
        self.b = concatenate((b1,b2))
        self.mat, self.b = treat_dirichlet_boundary_multivars(
            self.pt.P,
            self.pt.BN,
            self.pt.boundaries_name,
            self.pt.boundary_type_dict,
            self.pt.boundary_value_dict,
            self.mat,
            self.b
        )

        print("---------------------------FEM-Linear Elasticity------------------")

        print("---------------------------------------------------------")
        self.result = {}

    def solve(self):

        u = solve(self.mat, self.b)

        nn = self.u1.number_of_nodes
        v = [(u[i],u[nn+i]) for i in range(nn)]

        self.result['U'] = v
