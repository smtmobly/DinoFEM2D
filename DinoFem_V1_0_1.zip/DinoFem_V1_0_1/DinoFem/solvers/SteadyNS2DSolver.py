from DinoFem.Variantation import FemItemLoad,FemItemStiff,Variable,FemItemTransient
from DinoFem.numerical import solve,dot,Matrix,copy,concatenate,array
from DinoFem.FemOPS import assemble_matrix_2d,assemble_vector_2d,treat_dirichlet_boundary_multivars
from DinoFem.FemOPS import assemble_matrix_2d_iteration,assemble_vector_2d_iteration


class SteadyNS2DSolver:
    def __init__(self, pt,mu,load_fun,p0):
        self.pt = pt
        self.u1 = Variable("u1", self.pt.P, self.pt.T, self.pt.pattern)
        self.u2 = Variable("u2", self.pt.P, self.pt.T, self.pt.pattern)
        self.p = Variable("p", self.pt.P_mesh, self.pt.T_mesh, "linear")
        s1 = FemItemStiff(coe_fun=mu, test_der=[1, 0], trial_der=[1, 0], trial_var=self.u1,test_var=self.u1)
        s2 = FemItemStiff(coe_fun=mu, test_der=[0, 1], trial_der=[0, 1], trial_var=self.u1,test_var=self.u1)
        s3 = FemItemStiff(coe_fun=mu, test_der=[1, 0], trial_der=[0, 1], trial_var=self.u1,test_var=self.u1)
        # s4 = FemItemStiff(coe_fun=mu, test_der=[1, 0], trial_der=[1, 0], trial_fun_type='quad', test_fun_type='quad')
        s5 = FemItemStiff(coe_fun=-1, test_der=[1, 0], trial_der=[0, 0], trial_var=self.p,test_var=self.u1)
        s6 = FemItemStiff(coe_fun=-1, test_der=[0, 1], trial_der=[0, 0], trial_var=self.p,test_var=self.u1)
        # s7 = FemItemStiff(coe_fun=mu, test_der=[1, 0], trial_der=[1, 0], trial_fun_type='quad', test_fun_type='quad')
        # s8 = FemItemStiff(coe_fun=mu, test_der=[1, 0], trial_der=[1, 0], trial_fun_type='quad', test_fun_type='quad')
        # 迭代非线性部分的线性化矩阵
        self.l1 = FemItemStiff(coe_fun=1, trial_der=[0, 0], test_der=[0, 0], trial_var=self.u1,test_var=self.u1)
        self.l2 = FemItemStiff(coe_fun=1, trial_der=[1, 0], test_der=[0, 0], trial_var=self.u1, test_var=self.u1)
        self.l3 = FemItemStiff(coe_fun=1, trial_der=[0, 1], test_der=[0, 0], trial_var=self.u1, test_var=self.u1)
        self.lf = FemItemLoad(load_fun=1, test_var=self.u1)

        f1 = FemItemLoad(load_fun=load_fun[0], test_var=self.u1)
        f2 = FemItemLoad(load_fun=load_fun[1], test_var=self.u1)
        a11 = 2*assemble_matrix_2d(s1) + assemble_matrix_2d(s2)
        a12 = assemble_matrix_2d(s3)
        a13 = assemble_matrix_2d(s5)
        a21 = a12.transpose()
        a22 = 2*assemble_matrix_2d(s2) + assemble_matrix_2d(s1)
        a23 = assemble_matrix_2d(s6)
        a31 = a13.transpose()
        a32 = a23.transpose()
        # 处理p
        a33 = Matrix(self.p.number_of_nodes,self.p.number_of_nodes)

        c1 = concatenate((a11, a12, a13), axis=1)
        c2 = concatenate((a21, a22, a23), axis=1)
        c3 = concatenate((a31, a32, a33), axis=1)
        self.Mat = concatenate((c1, c2, c3))
        b1 = assemble_vector_2d(f1)
        b2 = assemble_vector_2d(f2)
        b3 = Matrix(self.p.number_of_nodes,1)
        self.b = concatenate((b1, b2, b3))
        # 为压力设置初始值
        self.p0 = p0
        n=2*self.u1.number_of_nodes
        self.Mat[n, :] = 0
        self.Mat[n, n] = 1
        self.b[n] = p0
        self.Mat, self.b = treat_dirichlet_boundary_multivars(
            self.pt.P,
            self.pt.BN,
            self.pt.boundaries_name,
            self.pt.boundary_type_dict,
            self.pt.boundary_value_dict,
            self.Mat,
            self.b
        )

        print("--------------------------- FEM-Stokes Equations ------------------")
        print("-----------------------------------------------------------------------")

        print("---- Solving -----")

        print("-----------------------------------------------------------------------")
        self.result = {}

    def solve(self,iterator_num=3):
        u_number = self.u1.number_of_nodes
        p_number = self.p.number_of_nodes
        u_old = None
        u_new = None
        # stokes方程计算u_0
        u_old = solve(self.Mat, self.b)
        O1 = Matrix(p_number,p_number)
        O2 = Matrix(u_number,p_number)
        O3 = Matrix(u_number,p_number)
        OB = Matrix(p_number, 1)
        print("---- Solving U,p -----")
        # 构筑迭代格式
        for l in range(iterator_num):
            AN1 = assemble_matrix_2d_iteration(self.l1, u_old, 0, [1, 0])
            AN2 = assemble_matrix_2d_iteration(self.l2, u_old, 0, [0, 0])
            AN3 = assemble_matrix_2d_iteration(self.l3, u_old, u_number, [0, 0])
            AN4 = assemble_matrix_2d_iteration(self.l1, u_old, 0, [0, 1])
            AN5 = assemble_matrix_2d_iteration(self.l1, u_old, u_number, [1, 0])
            AN6 = assemble_matrix_2d_iteration(self.l1, u_old, u_number, [0, 1])
            A_Nonlinear1 = concatenate((AN1+AN2+AN3,AN4,O2),axis=1)
            A_Nonlinear2 = concatenate((AN5,AN6+AN2+AN3,O3), axis=1)
            A_Nonlinear3 = concatenate((O2.transpose(), O3.transpose(), O1), axis=1)
            A_Nonlinear = concatenate((A_Nonlinear1,A_Nonlinear2,A_Nonlinear3))

            BN1 = assemble_vector_2d_iteration(self.lf, u_old, begin1=0, begin2=0, der1=[0, 0],
                                               der2=[1, 0])
            BN2 = assemble_vector_2d_iteration(self.lf, u_old, begin1=u_number, begin2= 0, der1=[0, 0],
                                               der2=[0, 1])
            BN3 = assemble_vector_2d_iteration(self.lf, u_old, begin1=0, begin2=u_number, der1=[0, 0],
                                               der2=[1, 0])
            BN4 = assemble_vector_2d_iteration(self.lf, u_old, begin1=u_number, begin2=u_number, der1=[0, 0],
                                               der2=[0, 1])
            BN = concatenate((BN1+BN2,BN3+BN4,OB))
            A_l = self.Mat+A_Nonlinear
            b_l = self.b+BN
            # 处理边界条件
            A_l, b_l = treat_dirichlet_boundary_multivars(
                self.pt.P,
                self.pt.BN,
                self.pt.boundaries_name,
                self.pt.boundary_type_dict,
                self.pt.boundary_value_dict,
                A_l,
                b_l
            )
            # 压力设置参考值
            n=2*self.u1.number_of_nodes
            A_l[n, :] = 0
            A_l[n, n] = 1
            b_l[n] = self.p0
            u_new = solve(A_l,b_l)
            u_old = u_new

        print("---- Saving U,p -----")
        v = [(u_new[i], u_new[u_number + i]) for i in range(u_number)]

        p = [u_new[2 * u_number + i] for i in range(p_number)]
        self.result['U'] = v
        self.result['p'] = p
        print("---- U saved! -----")

        print("---- p saved! -----")
        print("--------------------------- FEM-Steady-Navier-Stokes Equations Finished! ------------------")
