from DinoFem.Variantation import FemItemLoad,FemItemStiff,Variable
from DinoFem.numerical import solve
from DinoFem.FemOPS import assemble_matrix_2d,assemble_vector_2d,treat_dirichlet_boundary


class Poisson2DSolver:
    def __init__(self, pt, coe_fun,load_fun,var_name="T"):
        self.pt = pt

        self.var = Variable(var_name,self.pt.P, self.pt.T,self.pt.pattern)

        s1 = FemItemStiff(coe_fun=coe_fun,
                          trial_der=[1, 0],
                          test_der=[1, 0],
                          trial_var=self.var,
                          test_var=self.var
                          )
        s2 = FemItemStiff(coe_fun=coe_fun,
                          trial_der=[0, 1],
                          test_der=[0, 1],
                          trial_var=self.var,
                          test_var=self.var
                          )
        f= FemItemLoad(load_fun=load_fun,test_var=self.var)
        express = s1.express+'+'+s2.express+'='+f.express
        print("---------------------------FEM-Poisson------------------")
        print("Variation".upper())
        print(express)
        A1 = assemble_matrix_2d(s1)

        A2 = assemble_matrix_2d(s2)
        A= A1+A2

        b = assemble_vector_2d(f)
        self.A,self.b = treat_dirichlet_boundary(pt.P,
                                                 pt.BN,
                                                 pt.boundaries_name,
                                                 pt.boundary_type_dict,
                                                 pt.boundary_value_dict,
                                                 A,
                                                 b
                                                 )
        print("---------------------------------------------------------")
        # for i in range(A.shape[0]):
        #     print(self.A[i,i])
        self.result = {}

    def solve(self):

        self.result[self.var.name] = solve(self.A, self.b)



