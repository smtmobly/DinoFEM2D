from DinoFem.inp_analytic import InpAnalytic
from DinoFem.common import BdyType
from DinoFem.exceptions import ParamTypeError

# def boundary_type_update(self, d):
#     """
#     边界名称，对应 边界类型
#     对所有边界形成的字典.
#     在边界处理的时候，根据BN边界的index，通过boundaries_name找到边界名称，
#     再通过边界名称在这个字典中查找边界类型
#     :param d:例如，两个边界，boundary1和boundary2
#          -------------------------------------------------
#                            边界字典设定规则
#     ------------------------------------------------------------
#     |边界类型           |   数学表达       |   标记  |  值          |
#     |dirichlet        |     T=g         |    -1  |  g 函数类型    |
#     |齐次neumann       |   grad T =0     |   -2   |  None        |
#     |非齐次neumann      |    grad T = phi |    -3  |  phi 函数类型  |
#     ---------------------------------------------------------------
#
#
#     d={}
#     d.update(sub)
#     d.update({"boundary1":-1})
#     d.update({"boundary2":-2})
#     v={}
#     v.update({"boundary1":g})
#     v.update({"boundary2":None})
#
#
#
#     :return:
#     """
#     self.__boundary_name_type_dict = d


def creat_mesh_2d(inp_file,pattern='linear'):

    """
    :param inp_file: inp文件
    :param pattern:  单元类型，line 线性单元，quad，二次单元
    """
    if pattern == 'linear':
        pt = Mesh2DLinear()
        pt.get_pt_from_inp(inp_file)
        return pt
    elif pattern == 'quad':
        pt = Mesh2DQuad()
        pt.get_pt_from_inp(inp_file)
        return pt
    else:
        raise ParamTypeError(f'{pattern}  is not supported, linear or quad')


class Mesh2DQuad:
    def __init__(self):
        self.__P = None
        self.__T = None
        self.__BN = None
        self.__boundaries_name = None
        self.__boundary_name_type_dict = None
        self.__boundary_name_value_dict = None
        self.__P_mesh = None
        self.__T_mesh = None
        self.pattern = 'quad'
        self.P_mesh_index_to_P = None

    @property
    def boundary_type_dict(self):
        """
        边界名称，对应 边界类型
        对所有边界形成的字典
        :return:
        """
        return self.__boundary_name_type_dict

    @property
    def boundary_value_dict(self):
        """
        边界名称，对应 边界值
        对所有边界形成的字典
        :return:
        """
        return self.__boundary_name_value_dict

    def set_boundary(self,boundary_name, boundary_type, value=None):
        self.__boundary_name_type_dict[boundary_name]= boundary_type
        self.__boundary_name_value_dict[boundary_name] = value

    @property
    def boundaries_name(self):
        return self.__boundaries_name

    @property
    def T(self):
        return self.__T

    @property
    def P(self):
        return self.__P

    @property
    def T_mesh(self):
        return self.__T_mesh

    @property
    def P_mesh(self):
        return self.__P_mesh

    @property
    def BN(self):
        return self.__BN

    def initial_boundary_default(self):
        self.__boundary_name_type_dict = {}
        self.__boundary_name_value_dict = {}
        #  全部默认为齐次neumann边界条件
        for b in self.boundaries_name:
            type_sub = {b: BdyType.ZeroGradient}
            value_sub = {b: None}
            self.__boundary_name_type_dict.update(type_sub)
            self.__boundary_name_value_dict.update(value_sub)

    def get_pt_from_inp(self, inp_file):
        inp = InpAnalytic(inp_file, pattern='quad')
        self.__T = inp.T
        self.__P = inp.P
        self.__BN = inp.BN
        self.__boundaries_name = inp.boundaries_name
        self.initial_boundary_default()

        mesh_points = {}
        count = 0
        for p in self.__T:
            for p1 in p[:3]:
                if str(p1) in mesh_points.keys():
                    pass
                else:
                    mesh_points.update({str(p1): count})
                    count += 1
        self.P_mesh_index_to_P = [int(key) for key in mesh_points.keys()]
        self.__P_mesh = [self.__P[int(key)] for key in mesh_points.keys()]
        t_m = []
        for p in self.__T:
            item = []
            for p1 in p[:3]:
                item.append(mesh_points[str(p1)])
            t_m.append(item)

        self.__T_mesh = t_m


class Mesh2DLinear:
    def __init__(self):
        self.pattern = 'linear'
        self.__number_of_nodes = None
        self.__number_of_elements = None
        self.__number_of_boundary_nodes = None
        self.__P = None
        self.__T = None
        self.__BN = None
        self.__boundaries_name = None
        self.__number_of_boundaries = None
        self.__boundary_name_type_dict = None
        self.__boundary_name_value_dict = None
        self.__number_of_mesh_nodes = None

    @property
    def boundary_type_dict(self):
        """
        边界名称，对应 边界类型
        对所有边界形成的字典
        :return:
        """
        return self.__boundary_name_type_dict

    @property
    def boundary_value_dict(self):
        """
        边界名称，对应 边界值
        对所有边界形成的字典
        :return:
        """
        return self.__boundary_name_value_dict

    def boundary_type(self, k):
        if k < 0:
            return k
        return self.boundary_type_dict[self.boundaries_name[k]]

    def boundary_value(self,k):
        return self.boundary_value_dict[self.boundaries_name[k]]

    def set_boundary(self,boundary_name, boundary_type, value=None):
        self.__boundary_name_type_dict[boundary_name]= boundary_type
        self.__boundary_name_value_dict[boundary_name] = value

    @property
    def number_of_nodes(self):
        return self.__number_of_nodes
    @property
    def number_of_mesh_nodes(self):
        return self.__number_of_mesh_nodes

    @property
    def number_of_elements(self):
        return self.__number_of_elements

    @property
    def number_of_boundary_nodes(self):
        return self.__number_of_boundary_nodes

    @property
    def boundaries_name(self):
        return self.__boundaries_name

    @property
    def number_of_boundaries(self):
        return len(self.__boundaries_name)

    @property
    def T(self):
        return self.__T

    @property
    def P(self):
        return self.__P

    @property
    def T_mesh(self):
        return self.__T

    @property
    def P_mesh(self):
        return self.__P

    @property
    def BN(self):
        return self.__BN

    def initial_boundary_default(self):
        self.__boundary_name_type_dict = {}
        self.__boundary_name_value_dict = {}
        #  全部默认为齐次neumann边界条件
        for b in self.boundaries_name:
            type_sub = {b: BdyType.ZeroGradient}
            value_sub = {b: None}
            self.__boundary_name_type_dict.update(type_sub)
            self.__boundary_name_value_dict.update(value_sub)

    def get_pt_from_inp(self, inp_file):
        inp = InpAnalytic(inp_file, pattern='linear')
        self.__T = inp.T
        self.__P = inp.P
        self.__BN = inp.BN
        self.__boundaries_name = inp.boundaries_name
        self.__number_of_boundary_nodes = len(inp.BN)
        self.__number_of_elements = len(inp.T)
        self.__number_of_nodes = len(inp.P)
        self.__number_of_boundaries = len(inp.boundaries_name)
        self.initial_boundary_default()


class MeshPara2D:
    def __init__(self):
        self.number_of_nodes = None
        self.number_of_elements = None
        self.number_of_boundary_nodes = None
        self.boundaries_name = []
        self.P = None
        self.T = None
        self.BN = None

    def generate_by(self, left, right, bottom, top, N1, N2):
        self.number_of_nodes = (N1+1)*(N2+1)
        self.number_of_elements = 2*N1*N2
        self.number_of_boundary_nodes =2*(N1+N2)
        h1 = (right - left)/N1
        h2 = (top - bottom)/N2
        self.P = []
        self.T = []
        self.BN = []
        for j in range(self.number_of_nodes):
            cn = int(j / (N2+1))
            rn = int(j - cn * (N2 + 1))
            x = left + cn * h1
            y = bottom + rn * h2
            point = x, y
            self.P.append(point)
        for n in range(self.number_of_elements):
            ce = int(n / (2*N2))
            re = int(n - ce * (2*N2))
            # re 是偶数
            if re % 2 == 0:
                re = int(re/2)
                cn1 = ce
                rn1 = re
                cn2 = ce + 1
                rn2 = re
                cn3 = ce
                rn3 = re + 1
                j1 = cn1*(N2+1)+rn1
                j2 = cn2*(N2+1)+rn2
                j3 = cn3 * (N2 + 1) + rn3
                ele_list = j1,j2,j3
                self.T.append(ele_list)
            # re 是奇数
            else:
                re = int(re / 2)
                cn1 = ce
                rn1 = re+1
                cn2 = ce + 1
                rn2 = re
                cn3 = ce + 1
                rn3 = re + 1
                j1 = cn1*(N2+1)+rn1
                j2 = cn2*(N2+1)+rn2
                j3 = cn3 * (N2 + 1) + rn3
                ele_list = j1, j2, j3
                self.T.append(ele_list)

        # bottom 边界，re=0，ce = 0,...,N1-1
        boundary_index = 0
        self.boundaries_name.append("bottom")
        for k in range(N1):
            ce = k
            re = 0
            n = ce*2*N2 + re

            element_index = n
            bd_list = boundary_index, element_index, self.T[n][0], self.T[n][1]
            self.BN.append(bd_list)

        # right 边界，ce = N1-1,re = 1,3,...,2*N2-1，re是奇数
        boundary_index = 1
        self.boundaries_name.append("right")
        for k in range(N2):
            ce = N1-1
            re = 2*k + 1
            n = ce * 2 * N2 + re
            element_index = n
            bd_list = boundary_index, element_index, self.T[n][1], self.T[n][2]
            self.BN.append(bd_list)

        # top 边界，re=2*N2-1，ce = N1-1,...,0
        boundary_index = 2
        self.boundaries_name.append("up")
        for k in range(N1):
            ce = N1-1 - k
            re = 2*N2 - 1
            n = ce * 2 * N2 + re
            element_index = n
            bd_list = boundary_index, element_index, self.T[n][2], self.T[n][0]
            self.BN.append(bd_list)

        # left 边界，ce = 0 ,re=2*(N2-1),...,4,2,0
        boundary_index = 3
        self.boundaries_name.append("left")
        for k in range(N2):
            ce = 0
            re = 2*(N2-1-k)
            n = ce * 2 * N2 + re
            element_index = n
            bd_list = boundary_index, element_index, self.T[n][2], self.T[n][0]
            self.BN.append(bd_list)


if __name__ == '__main__':
    inpfile = r"D:\DinoFemTut\t1_quard.inp"
    pt = Mesh2DQuad()
    pt.get_pt_from_inp(inpfile)
    P_mesh = pt.P_mesh
    T_mesh = pt.T_mesh
    print(pt.T[:5])
    print(pt.T_mesh[:5])
    # faces = []
    # for f in T_mesh:
    #     fip = 3,*f
    #     faces += fip
    # import pyvista as pv
    # mesh = pv.PolyData(P_mesh,faces)
    # mesh.plot(show_edges=True)







