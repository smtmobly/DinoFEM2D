import numpy as np
import pyvista as pv

from DinoFem.solvers.Poisson2DSolver import Poisson2DSolver
from math import exp, sin, cos, pi
from DinoFem.Mesh import creat_mesh_2d
from DinoFem import BdyType


def solution(x,y):
    return sin(2*pi*x)*cos(2*pi*y)

def ceo_fun(x,y):
    return 1

def force_fun(x, y):
    return 8*pi**2*sin(2*pi*x)*cos(2*pi*y)

def g(x, y):
    return solution(x, y)


def run(inp_file, pattern, ceo_fun, force_fun):
    """

    :param inp_file: inp文件地址
    :param pattern:  inp网格类型:linear or quad
    :param ceo_fun:  laplace 项的系数
    :param force_fun: 源函数
    :return:
    """
    # ------
    # 生成网格
    # --------

    pt = creat_mesh_2d(inp_file, pattern)
    # -----------
    # 设定边界条件
    # 边界条件与边界值，是对应的。
    # ------------
    pt.set_boundary("outwall", BdyType.Dirichlet, g)
    # pt.set_boundary("inwall", BdyType.Dirichlet,g2)

    # -----------------------------------
    #  求解器输入网格，方程系数，外力函数和边界函数
    # ------------------------------------
    fem = Poisson2DSolver(pt=pt,
                          coe_fun=ceo_fun,  # 方程的系数
                          load_fun=force_fun,  # 源项
                          )
    # 求解
    fem.solve()
    points = pt.P

    faces = []
    for f in pt.T:
        fids = 3, *f[:3]
        faces += fids
    mesh = pv.PolyData(points,faces)
    result = fem.result[fem.var.name]
    mesh.point_data[fem.var.name]=result
    sol = np.zeros((len(points),))
    for i in range(len(points)):
        x,y,_ = points[i]
        sol[i]=solution(x,y)
    error = np.zeros((len(points),))
    for i in range(len(points)):
        x,y,_ = points[i]
        error[i]=abs(solution(x,y)-result[i])
    mesh.point_data['sol'] = sol
    mesh.point_data['error'] = error
    return mesh


if __name__ == '__main__':
    exam_path = "../examples"
    inp_file_linear = exam_path+"/aquare_linear.inp"
    inp_file_quad = exam_path+"/aquare_quad.inp"
    mesh = run(inp_file=inp_file_quad, ceo_fun=ceo_fun, force_fun=force_fun,pattern='quad')
    mesh.save(exam_path+"/quad_poisson.vtk")


