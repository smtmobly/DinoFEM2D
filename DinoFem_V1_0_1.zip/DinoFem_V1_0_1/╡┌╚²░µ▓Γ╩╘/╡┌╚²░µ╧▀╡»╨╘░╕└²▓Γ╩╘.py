import numpy
import pyvista as pv

from DinoFem.solvers.LinearElasticity2DSolver import LinearElasticity2DSolver
from math import exp, sin, cos, pi
from DinoFem.Mesh import creat_mesh_2d
from DinoFem2D import BdyType
lam = 1
mu =2
def f1(x,y,t=0):
    return -(lam+2*mu)*(-pi**2*sin(pi*x)*sin(pi*y))\
        - (lam+mu)*((2*x-1)*(2*y-1))\
        - mu*(-pi**2*sin(pi*x)*sin(pi*y))

def f2(x,y,t=0):
    return -(lam + 2 * mu) * (2*x*(x-1)) \
        - (lam + mu) * pi**2*cos(pi*x)*cos(pi*y) \
        - mu * (2*y*(y-1))

def solution_u1(x,y,t=0):
    return sin(pi*x)*sin(pi*y)

def solution_u2(x,y,t=0):
    return x*(x-1)*y*(y-1)


def run(inp_file, lam, mu,load_fun,pattern):
    # ------
    # 生成网格
    # --------
    pt = creat_mesh_2d(inp_file,pattern)
    pt.get_pt_from_inp(inp_file)
    # -----------
    # 设定边界条件
    # 边界条件与边界值，是对应的。
    # ------------
    pt.set_boundary("outwall", BdyType.Dirichlet,[solution_u1,solution_u2])
    pt.set_boundary("inwall", BdyType.Dirichlet,[solution_u1,solution_u2])

    fem = LinearElasticity2DSolver(pt=pt,
                                   lam=lam,  # 方程的系数
                                   mu=mu,
                                   load_fun=load_fun
                                   )
    # 求解
    fem.solve()
    points = pt.P

    faces = []
    for f in pt.T:
        fids = 3, *f[:3]
        faces += fids
    mesh = pv.PolyData(points, faces)

    sol = fem.result['U']
    mesh.point_data['U']=sol
    number_of_nodes = fem.u1.number_of_nodes
    u_real = numpy.array([(solution_u1(pt.P[i][0], pt.P[i][1]),
                         +solution_u2(pt.P[i][0], pt.P[i][1]))
                         for i in range(number_of_nodes)])
    u_mag = numpy.array([(solution_u1(pt.P[i][0], pt.P[i][1])**2
                         + solution_u2(pt.P[i][0], pt.P[i][1])**2)**0.5
                         for i in range(number_of_nodes)])
    error = numpy.array([(abs(sol[i][0] - solution_u1(pt.P[i][0], pt.P[i][1]))
                         +abs(sol[i][1] - solution_u2(pt.P[i][0], pt.P[i][1])))/
                         (abs(solution_u1(pt.P[i][0], pt.P[i][1]))+abs(solution_u2(pt.P[i][0], pt.P[i][1]))+10**(-6))
                         for i in range(number_of_nodes)])
    mesh.point_data['error'] = error
    mesh.point_data['u_real'] = u_real
    mesh.point_data['u_mag'] = u_mag

    return mesh


if __name__ == '__main__':
    import multiprocessing,os

    inp_file_linear = r"D:\DinoFemTut\aquare_linear.inp"
    inp_file_quad = r"D:\DinoFemTut\aquare_quad.inp"
    mesh = run(inp_file=inp_file_linear,lam=lam, mu=mu,load_fun=(f1,f2),pattern="linear")
    data_folder = os.path.abspath(r"D:\DinoFemTut")
    filename = os.path.join(data_folder, 'elasticiy' + ".vtk")
    mesh.save(filename)
    # # print(mesh.point_data)
    #
    # p= pv.Plotter()
    # p.add_mesh(mesh,
    #            scalars='T',
    #            cmap="rainbow",
    #            lighting=True,
    #            scalar_bar_args={'title': 'T'},
    #            show_edges=True,
    #            edge_color="green",
    #            )
    #
    # p.show(title="Post Show")

    # from DinoFem2D.postprocess import post_show
    #
    # p1 = multiprocessing.Process(target=post_show, args=(mesh, 'T',0.1,False,True))
    # p2 = multiprocessing.Process(target=post_show, args=(mesh, 'T',0.1,True,True))
    # p1.start()
    # p2.start()
    # p1.join()
    # p2.join()
