import numpy as np
import pyvista as pv

from DinoFem.solvers.SteadyNS2DSolver import SteadyNS2DSolver
from math import exp, sin, cos, pi
from DinoFem.Mesh import creat_mesh_2d
from DinoFem2D import BdyType

mu = 1


def f1(x,y,t=0):
    return -2*mu*x**2-2*mu*y**2-mu*exp(-y)+pi**2*cos(pi*x)*cos(2*pi*y)+\
        2*x*y**2*(x**2*y**2+exp(-y))+(-2*x*y**3/3+2-pi*sin(pi*x))*(2*x**2*y-exp(-y))


def f2(x,y,t=0):
    return 4*mu*x*y - mu*pi**3*sin(pi*x)+2*pi*(2-pi*sin(pi*x))*sin(2*pi*y)+\
        (x**2*y**2+exp(-y))*(-2*y**3/3-pi**2*cos(pi*x))+\
        (-2*x*y**3/3+2-pi*sin(pi*x))*(-2*x*y**2)


def solution_u1(x, y, t=0):
    return x**2*y**2+exp(-y)


def solution_u2(x, y, t=0):
    return -2/3*x*y**3 + 2 - pi*sin(pi*x)


def p(x, y, t=0):
    return -1*(2-pi*sin(pi*x))*cos(2*pi*y)


def run(inp_file, mu,load_fun):
    pt = creat_mesh_2d(inp_file,pattern='quad')
    pt.set_boundary("outwall", BdyType.Dirichlet,[solution_u1,solution_u2])
    pt.set_boundary("inwall", BdyType.Dirichlet,[solution_u1,solution_u2])
    points_U = pt.P

    faces = []
    for f in pt.T:
        fids = 3, *f[:3]
        faces += fids
    points_p = pt.P_mesh
    p0 = p(points_p[0][0],points_p[0][1])
    faces = []
    for f in pt.T_mesh:
        fids = 3, *f[:3]
        faces += fids
    mesh_p = pv.PolyData(points_p, faces)
    fem = SteadyNS2DSolver(pt=pt,
                         mu=mu,
                         load_fun=load_fun,
                         p0=p0
                         )
    # 求解
    fem.solve()

    u_sol = []

    for i in range(fem.p.number_of_nodes):
        k = pt.P_mesh_index_to_P[i]
        u_sol.append(fem.result['U'][k])
    u_sol = np.array(u_sol)
    mesh_p.point_data['U'] = u_sol
    u_err = np.zeros((fem.p.number_of_nodes,1))
    for i in range(fem.p.number_of_nodes):
        x,y,_ = points_p[i]
        u1,u2 = u_sol[i]
        u_err[i] = abs(solution_u1(x,y)-u1)+abs(solution_u2(x,y)-u2)
    mesh_p.point_data['uerr'] = u_err
    mesh_p.point_data['p'] = fem.result['p']
    p_err = np.zeros((fem.p.number_of_nodes,1))
    for i in range(fem.p.number_of_nodes):
        x,y,_ = points_p[i]
        p_i = fem.result['p'][i]
        p_err[i] = abs(p(x,y)-p_i)
    mesh_p.point_data['perr']=p_err
    data_folder = os.path.abspath(r"D:\DinoFemTut")
    filename2 = os.path.join(data_folder, 'steady_stokes' + ".vtk")
    mesh_p.save(filename2)
    return "ok"


if __name__ == '__main__':
    import os
    inp_file_quad = r"D:\DinoFemTut\aquare_quad.inp"
    run(inp_file=inp_file_quad, mu=mu,load_fun=(f1,f2))


