import numpy as np
import pyvista as pv

from DinoFem.solvers.Parabolic2DSolver import Parabolic2DSolver
from math import exp, sin, cos, pi
from DinoFem.Mesh import creat_mesh_2d
from DinoFem import BdyType


def solution(x,y,t):
    return exp(x+y+t)


def ceo_fun(x,y,t=0):
    return 2


def force_fun(x, y,t):
    return -3*exp(x+y+t)


def g1(x, y,t=0):
    return solution(x,y,t)

def g2(x, y,t=0):
    return solution(x,y,t)

def initial_value(x,y):
    return solution(x,y,0)


def run(inp_file, pattern, ceo_fun, force_fun):
    """

    :param inp_file: inp文件地址
    :param pattern:  inp网格类型:linear or quad
    :param ceo_fun:  laplace 项的系数
    :param force_fun: 源函数
    :return:
    """
    # ------
    # 生成网格
    # --------

    pt = creat_mesh_2d(inp_file, pattern)
    # -----------
    # 设定边界条件
    # 边界条件与边界值，是对应的。
    # ------------
    pt.set_boundary("outwall", BdyType.Dirichlet,g1)
    #pt.set_boundary("inwall", BdyType.Dirichlet,g2)

    # -----------------------------------
    #  求解器输入网格，方程系数，外力函数和边界函数
    # ------------------------------------
    start =0
    end = 1
    steps = 20
    fem = Parabolic2DSolver(pt=pt,
                            coe_fun=ceo_fun,  # 方程的系数
                            load_fun=force_fun,  # 源项
                            start=0,
                            end=1,
                            steps=steps,
                            initial_value=initial_value
                          )
    # 求解
    fem.solve()
    points = pt.P

    faces = []
    for f in pt.T:
        fids = 3, *f[:3]
        faces += fids
    result = fem.result[fem.var.name]
    dt = (end-start)/steps
    for m in range(steps+1):
        mesh = pv.PolyData(points, faces)
        mesh.point_data[fem.var.name]=result[:,m]
        sol = np.zeros((len(points),))
        for i in range(len(points)):
            x, y, _ = points[i]
            sol[i] = solution(x, y, m*dt)
        error = np.zeros((len(points),))
        for i in range(len(points)):
            x, y, _ = points[i]
            error[i] = abs(solution(x, y,m*dt) - result[i, m])
        mesh.point_data['sol'] = sol
        mesh.point_data['error'] = error
        filename = r"..\examples\parabolic"+"\\"+str(m*dt)+".vtk"
        mesh.save(filename)


if __name__ == '__main__':
    exam_path = "../examples"
    inp_file_linear = exam_path + "/aquare_linear.inp"
    inp_file_quad = exam_path + "/aquare_quad.inp"
    test_linear = exam_path+"/t3_linear.inp"
    test_quad = exam_path+"/t3_quad.inp"
    inp_file_linear_half = exam_path + "/aquare_linear_half.inp"
    run(inp_file=inp_file_linear, ceo_fun=ceo_fun, force_fun=force_fun,pattern='linear')

