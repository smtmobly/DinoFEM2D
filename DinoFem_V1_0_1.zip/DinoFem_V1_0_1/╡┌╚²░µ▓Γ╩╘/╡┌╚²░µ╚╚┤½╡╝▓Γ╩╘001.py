import numpy as np
import pyvista as pv

from DinoFem.solvers.Parabolic2DSolver import Parabolic2DSolver
from DinoFem.solvers.Poisson2DSolver import Poisson2DSolver
from math import exp, sin, cos, pi
from DinoFem.Mesh import creat_mesh_2d
from DinoFem2D import BdyType


def solution(x,y,t):
    return exp(x+y+t)


def ceo_fun(x,y,t=0):
    return -3


def force_fun(x, y,t):
    return 300*sin(t)


def g1(x, y,t=0):
    return 10

def g2(x, y,t=0):
    return 20

# def initial_value(x,y,*args):
#     return solution(x,y,0)

# 初值处理
# possion方程求解

def deal_initial(inp_file, pattern, ceo_fun, force_fun):
    """

    :param inp_file: inp文件地址
    :param pattern:  inp网格类型:linear or quad
    :param ceo_fun:  laplace 项的系数
    :param force_fun: 源函数
    :return:
    """
    # ------
    # 生成网格
    # --------

    pt = creat_mesh_2d(inp_file, pattern)
    # -----------
    # 设定边界条件
    # 边界条件与边界值，是对应的。
    # ------------
    # pt.set_boundary("outwall", BdyType.Dirichlet,g1)
    pt.set_boundary("inwall", BdyType.Dirichlet,g2)

    # -----------------------------------
    #  求解器输入网格，方程系数，外力函数和边界函数
    # ------------------------------------
    fem = Poisson2DSolver(pt=pt,
                          coe_fun=ceo_fun,  # 方程的系数
                          load_fun=force_fun,  # 源项
                          )
    # 求解
    fem.solve()
    return fem.result[fem.var.name]





def run(inp_file, pattern, ceo_fun, force_fun):
    """

    :param inp_file: inp文件地址
    :param pattern:  inp网格类型:linear or quad
    :param ceo_fun:  laplace 项的系数
    :param force_fun: 源函数
    :return:
    """
    # ------
    # 生成网格
    # --------

    pt = creat_mesh_2d(inp_file, pattern)
    # -----------
    # 设定边界条件
    # 边界条件与边界值，是对应的。
    # ------------
    # pt.set_boundary("outwall", BdyType.Dirichlet,g1)
    pt.set_boundary("inwall", BdyType.Dirichlet,g2)
    initial_value = deal_initial(inp_file, pattern, ceo_fun, 0)

    # -----------------------------------
    #  求解器输入网格，方程系数，外力函数和边界函数
    # ------------------------------------
    fem = Parabolic2DSolver(pt=pt,
                            coe_fun=ceo_fun,  # 方程的系数
                            load_fun=force_fun,  # 源项
                            start=0,
                            end=10,
                            steps=10,
                            initial_value=initial_value
                          )
    # 求解
    fem.solve()
    points = pt.P

    faces = []
    for f in pt.T:
        fids = 3, *f[:3]
        faces += fids
    result = fem.result
    print(result.keys())
    for key in result.keys():
        mesh = pv.PolyData(points, faces)
        mesh.point_data[fem.var.name]=result[key]
        name = "result_"+str(float(key)*100+10000)[1:-2]
        filename = r"D:\DinoFemTut\parabolic"+"\\"+name+".vtk"
        mesh.save(filename)


if __name__ == '__main__':
    import multiprocessing
    inp_file_linear = r"D:\DinoFemTut\t1.inp"
    inp_file_quad = r"D:\DinoFemTut\t1_quard.inp"
    test_linear = r"D:\DinoFemTut\t3_linear.inp"
    test_quad = r"D:\DinoFemTut\t3_quad.inp"
    run(inp_file=inp_file_quad, ceo_fun=ceo_fun, force_fun=force_fun,pattern='quad')

